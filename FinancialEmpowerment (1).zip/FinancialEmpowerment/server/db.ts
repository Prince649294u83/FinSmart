import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@shared/schema";

const { Pool } = pg;

// Create a PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Log connection status
pool.on("connect", () => {
  console.log("Connected to PostgreSQL database");
});

pool.on("error", (err) => {
  console.error("Unexpected error on idle client", err);
  process.exit(-1);
});

// Create a Drizzle ORM instance with the connection pool
export const db = drizzle(pool, { schema });

// Function to test database connection
export async function testConnection(): Promise<boolean> {
  try {
    await pool.query("SELECT NOW()");
    return true;
  } catch (error) {
    console.error("Database connection test failed:", error);
    return false;
  }
}