import {
  users, type User, type InsertUser,
  budgets, type Budget, type InsertBudget,
  savingsGoals, type SavingsGoal, type InsertSavingsGoal,
  investments, type Investment, type InsertInvestment,
  quizResults, type QuizResult, type InsertQuizResult,
  subscribers, type Subscriber, type InsertSubscriber,
  courses, type Course, type InsertCourse,
  modules, type Module, type InsertModule,
  lessons, type Lesson, type InsertLesson,
  userProgress, type UserProgress, type InsertUserProgress,
  transactions, type Transaction, type InsertTransaction,
  analyticReports, type AnalyticReport, type InsertAnalyticReport, 
  anomalyAlerts, type AnomalyAlert, type InsertAnomalyAlert,
  goalUpdates, type GoalUpdate, type InsertGoalUpdate
} from "@shared/schema";

import session from "express-session";

export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User>;
  
  // Budget methods
  createBudget(budget: InsertBudget): Promise<Budget>;
  getBudget(id: number): Promise<Budget | undefined>;
  getBudgetsByUserId(userId: number): Promise<Budget[]>;
  
  // Savings goal methods
  createSavingsGoal(goal: InsertSavingsGoal): Promise<SavingsGoal>;
  getSavingsGoal(id: number): Promise<SavingsGoal | undefined>;
  getSavingsGoalsByUserId(userId: number): Promise<SavingsGoal[]>;
  updateSavingsGoal(id: number, goal: Partial<InsertSavingsGoal>): Promise<SavingsGoal>;
  
  // Investment methods
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  getInvestment(id: number): Promise<Investment | undefined>;
  getInvestmentsByUserId(userId: number): Promise<Investment[]>;
  updateInvestment(id: number, investment: Partial<InsertInvestment>): Promise<Investment>;
  
  // Quiz results methods
  createQuizResult(result: InsertQuizResult): Promise<QuizResult>;
  getQuizResult(id: number): Promise<QuizResult | undefined>;
  getQuizResultsByUserId(userId: number): Promise<QuizResult[]>;
  
  // Newsletter subscriber methods
  createSubscriber(subscriber: InsertSubscriber): Promise<Subscriber>;
  getSubscriberByEmail(email: string): Promise<Subscriber | undefined>;
  getAllSubscribers(): Promise<Subscriber[]>;

  // Course methods
  createCourse(course: InsertCourse): Promise<Course>;
  getCourse(id: number): Promise<Course | undefined>;
  getAllCourses(): Promise<Course[]>;
  getCoursesByCategory(category: string): Promise<Course[]>;
  getCoursesByLevel(level: string): Promise<Course[]>;
  updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course>;
  deleteCourse(id: number): Promise<boolean>;

  // Module methods
  createModule(module: InsertModule): Promise<Module>;
  getModule(id: number): Promise<Module | undefined>;
  getModulesByCourseId(courseId: number): Promise<Module[]>;
  updateModule(id: number, module: Partial<InsertModule>): Promise<Module>;
  deleteModule(id: number): Promise<boolean>;

  // Lesson methods
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  getLesson(id: number): Promise<Lesson | undefined>;
  getLessonsByModuleId(moduleId: number): Promise<Lesson[]>;
  updateLesson(id: number, lesson: Partial<InsertLesson>): Promise<Lesson>;
  deleteLesson(id: number): Promise<boolean>;

  // User Progress methods
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  getUserProgress(id: number): Promise<UserProgress | undefined>;
  getUserProgressByUserAndCourse(userId: number, courseId: number): Promise<UserProgress | undefined>;
  getUserProgressByUserAndModule(userId: number, moduleId: number): Promise<UserProgress | undefined>;
  getUserProgressByUserAndLesson(userId: number, lessonId: number): Promise<UserProgress | undefined>;
  updateUserProgress(id: number, progress: Partial<InsertUserProgress>): Promise<UserProgress>;
  getAllUserProgressByUserId(userId: number): Promise<UserProgress[]>;
  
  // Transaction methods
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  getTransactionsByUserId(userId: number): Promise<Transaction[]>;
  getTransactionsByUserIdAndDateRange(userId: number, startDate: Date, endDate: Date): Promise<Transaction[]>;
  getTransactionsByCategory(userId: number, category: string): Promise<Transaction[]>;
  
  // Analytics Report methods
  createAnalyticReport(report: InsertAnalyticReport): Promise<AnalyticReport>;
  getAnalyticReport(id: number): Promise<AnalyticReport | undefined>;
  getAnalyticReportsByUserId(userId: number): Promise<AnalyticReport[]>;
  getAnalyticReportsByType(userId: number, type: string): Promise<AnalyticReport[]>;
  deleteAnalyticReport(id: number): Promise<boolean>;
  
  // Anomaly Alert methods
  createAnomalyAlert(alert: InsertAnomalyAlert): Promise<AnomalyAlert>;
  getAnomalyAlert(id: number): Promise<AnomalyAlert | undefined>;
  getAnomalyAlertsByUserId(userId: number): Promise<AnomalyAlert[]>;
  updateAnomalyAlert(id: number, updates: Partial<InsertAnomalyAlert>): Promise<AnomalyAlert>;
  getUnreadAnomalyAlertsByUserId(userId: number): Promise<AnomalyAlert[]>;
  
  // Goal Updates methods
  createGoalUpdate(update: InsertGoalUpdate): Promise<GoalUpdate>;
  getGoalUpdate(id: number): Promise<GoalUpdate | undefined>;
  getGoalUpdatesByGoalId(goalId: number): Promise<GoalUpdate[]>;
  getGoalUpdatesByUserId(userId: number): Promise<GoalUpdate[]>;
}

import { db } from "./db";
import { eq, and, desc, asc, gte, lte } from "drizzle-orm";
import connectPgSimple from "connect-pg-simple";
import createMemoryStore from "memorystore";

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    // Use memory store for session
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // For production, uncomment to use PostgreSQL session store
    /*
    const PgStore = connectPgSimple(session);
    this.sessionStore = new PgStore({
      conString: process.env.DATABASE_URL,
      createTableIfMissing: true
    });
    */
  }
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    
    if (!updatedUser) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    return updatedUser;
  }
  
  // Budget methods
  async createBudget(insertBudget: InsertBudget): Promise<Budget> {
    const [budget] = await db
      .insert(budgets)
      .values(insertBudget)
      .returning();
    return budget;
  }
  
  async getBudget(id: number): Promise<Budget | undefined> {
    const [budget] = await db.select().from(budgets).where(eq(budgets.id, id));
    return budget || undefined;
  }
  
  async getBudgetsByUserId(userId: number): Promise<Budget[]> {
    return await db.select().from(budgets).where(eq(budgets.userId, userId));
  }
  
  // Savings goal methods
  async createSavingsGoal(insertGoal: InsertSavingsGoal): Promise<SavingsGoal> {
    const [goal] = await db
      .insert(savingsGoals)
      .values(insertGoal)
      .returning();
    return goal;
  }
  
  async getSavingsGoal(id: number): Promise<SavingsGoal | undefined> {
    const [goal] = await db.select().from(savingsGoals).where(eq(savingsGoals.id, id));
    return goal || undefined;
  }
  
  async getSavingsGoalsByUserId(userId: number): Promise<SavingsGoal[]> {
    return await db.select().from(savingsGoals).where(eq(savingsGoals.userId, userId));
  }
  
  async updateSavingsGoal(id: number, updates: Partial<InsertSavingsGoal>): Promise<SavingsGoal> {
    const [updatedGoal] = await db
      .update(savingsGoals)
      .set(updates)
      .where(eq(savingsGoals.id, id))
      .returning();
    
    if (!updatedGoal) {
      throw new Error(`Savings goal with ID ${id} not found`);
    }
    
    return updatedGoal;
  }
  
  // Investment methods
  async createInvestment(insertInvestment: InsertInvestment): Promise<Investment> {
    const [investment] = await db
      .insert(investments)
      .values(insertInvestment)
      .returning();
    return investment;
  }
  
  async getInvestment(id: number): Promise<Investment | undefined> {
    const [investment] = await db.select().from(investments).where(eq(investments.id, id));
    return investment || undefined;
  }
  
  async getInvestmentsByUserId(userId: number): Promise<Investment[]> {
    return await db.select().from(investments).where(eq(investments.userId, userId));
  }
  
  async updateInvestment(id: number, updates: Partial<InsertInvestment>): Promise<Investment> {
    const [updatedInvestment] = await db
      .update(investments)
      .set(updates)
      .where(eq(investments.id, id))
      .returning();
    
    if (!updatedInvestment) {
      throw new Error(`Investment with ID ${id} not found`);
    }
    
    return updatedInvestment;
  }
  
  // Quiz results methods
  async createQuizResult(insertResult: InsertQuizResult): Promise<QuizResult> {
    const [result] = await db
      .insert(quizResults)
      .values(insertResult)
      .returning();
    return result;
  }
  
  async getQuizResult(id: number): Promise<QuizResult | undefined> {
    const [result] = await db.select().from(quizResults).where(eq(quizResults.id, id));
    return result || undefined;
  }
  
  async getQuizResultsByUserId(userId: number): Promise<QuizResult[]> {
    return await db.select().from(quizResults).where(eq(quizResults.userId, userId));
  }
  
  // Newsletter subscriber methods
  async createSubscriber(insertSubscriber: InsertSubscriber): Promise<Subscriber> {
    const [subscriber] = await db
      .insert(subscribers)
      .values(insertSubscriber)
      .returning();
    return subscriber;
  }
  
  async getSubscriberByEmail(email: string): Promise<Subscriber | undefined> {
    const [subscriber] = await db.select().from(subscribers).where(eq(subscribers.email, email));
    return subscriber || undefined;
  }
  
  async getAllSubscribers(): Promise<Subscriber[]> {
    return await db.select().from(subscribers);
  }

  // Course methods
  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db
      .insert(courses)
      .values(insertCourse)
      .returning();
    return course;
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course || undefined;
  }

  async getAllCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  async getCoursesByCategory(category: string): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.category, category));
  }

  async getCoursesByLevel(level: string): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.level, level));
  }

  async updateCourse(id: number, updates: Partial<InsertCourse>): Promise<Course> {
    const [updatedCourse] = await db
      .update(courses)
      .set(updates)
      .where(eq(courses.id, id))
      .returning();
    
    if (!updatedCourse) {
      throw new Error(`Course with ID ${id} not found`);
    }
    
    return updatedCourse;
  }

  async deleteCourse(id: number): Promise<boolean> {
    try {
      await db.delete(courses).where(eq(courses.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting course:", error);
      return false;
    }
  }

  // Module methods
  async createModule(insertModule: InsertModule): Promise<Module> {
    const [courseModule] = await db
      .insert(modules)
      .values(insertModule)
      .returning();
    return courseModule;
  }

  async getModule(id: number): Promise<Module | undefined> {
    const [courseModule] = await db.select().from(modules).where(eq(modules.id, id));
    return courseModule || undefined;
  }

  async getModulesByCourseId(courseId: number): Promise<Module[]> {
    return await db
      .select()
      .from(modules)
      .where(eq(modules.courseId, courseId))
      .orderBy(asc(modules.order));
  }

  async updateModule(id: number, updates: Partial<InsertModule>): Promise<Module> {
    const [updatedModule] = await db
      .update(modules)
      .set(updates)
      .where(eq(modules.id, id))
      .returning();
    
    if (!updatedModule) {
      throw new Error(`Module with ID ${id} not found`);
    }
    
    return updatedModule;
  }

  async deleteModule(id: number): Promise<boolean> {
    try {
      await db.delete(modules).where(eq(modules.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting module:", error);
      return false;
    }
  }

  // Lesson methods
  async createLesson(insertLesson: InsertLesson): Promise<Lesson> {
    const [lesson] = await db
      .insert(lessons)
      .values(insertLesson)
      .returning();
    return lesson;
  }

  async getLesson(id: number): Promise<Lesson | undefined> {
    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id));
    return lesson || undefined;
  }

  async getLessonsByModuleId(moduleId: number): Promise<Lesson[]> {
    return await db
      .select()
      .from(lessons)
      .where(eq(lessons.moduleId, moduleId))
      .orderBy(asc(lessons.order));
  }

  async updateLesson(id: number, updates: Partial<InsertLesson>): Promise<Lesson> {
    const [updatedLesson] = await db
      .update(lessons)
      .set(updates)
      .where(eq(lessons.id, id))
      .returning();
    
    if (!updatedLesson) {
      throw new Error(`Lesson with ID ${id} not found`);
    }
    
    return updatedLesson;
  }

  async deleteLesson(id: number): Promise<boolean> {
    try {
      await db.delete(lessons).where(eq(lessons.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting lesson:", error);
      return false;
    }
  }

  // User Progress methods
  async createUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    const [progress] = await db
      .insert(userProgress)
      .values(insertProgress)
      .returning();
    return progress;
  }

  async getUserProgress(id: number): Promise<UserProgress | undefined> {
    const [progress] = await db.select().from(userProgress).where(eq(userProgress.id, id));
    return progress || undefined;
  }

  async getUserProgressByUserAndCourse(userId: number, courseId: number): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(and(
        eq(userProgress.userId, userId),
        eq(userProgress.courseId, courseId)
      ));
    return progress || undefined;
  }

  async getUserProgressByUserAndModule(userId: number, moduleId: number): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(and(
        eq(userProgress.userId, userId),
        eq(userProgress.moduleId, moduleId)
      ));
    return progress || undefined;
  }

  async getUserProgressByUserAndLesson(userId: number, lessonId: number): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(and(
        eq(userProgress.userId, userId),
        eq(userProgress.lessonId, lessonId)
      ));
    return progress || undefined;
  }

  async updateUserProgress(id: number, updates: Partial<InsertUserProgress>): Promise<UserProgress> {
    const [updatedProgress] = await db
      .update(userProgress)
      .set(updates)
      .where(eq(userProgress.id, id))
      .returning();
    
    if (!updatedProgress) {
      throw new Error(`User progress with ID ${id} not found`);
    }
    
    return updatedProgress;
  }

  async getAllUserProgressByUserId(userId: number): Promise<UserProgress[]> {
    return await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, userId))
      .orderBy(desc(userProgress.lastAccessedAt));
  }

  // Transaction methods
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }

  async getTransaction(id: number): Promise<Transaction | undefined> {
    const [transaction] = await db.select().from(transactions).where(eq(transactions.id, id));
    return transaction || undefined;
  }

  async getTransactionsByUserId(userId: number): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.date));
  }

  async getTransactionsByUserIdAndDateRange(userId: number, startDate: Date, endDate: Date): Promise<Transaction[]> {
    const startDateStr = startDate.toISOString().split('T')[0];
    const endDateStr = endDate.toISOString().split('T')[0];
    
    return await db
      .select()
      .from(transactions)
      .where(and(
        eq(transactions.userId, userId),
        and(
          // We need to use simple comparison operators since we can't use db.sql
          // date is >= startDate
          gte(transactions.date, startDateStr),
          // date is <= endDate
          lte(transactions.date, endDateStr)
        )
      ))
      .orderBy(desc(transactions.date));
  }

  async getTransactionsByCategory(userId: number, category: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(and(
        eq(transactions.userId, userId),
        eq(transactions.category, category)
      ))
      .orderBy(desc(transactions.date));
  }

  // Analytics Report methods
  async createAnalyticReport(insertReport: InsertAnalyticReport): Promise<AnalyticReport> {
    const [report] = await db
      .insert(analyticReports)
      .values(insertReport)
      .returning();
    return report;
  }

  async getAnalyticReport(id: number): Promise<AnalyticReport | undefined> {
    const [report] = await db.select().from(analyticReports).where(eq(analyticReports.id, id));
    return report || undefined;
  }

  async getAnalyticReportsByUserId(userId: number): Promise<AnalyticReport[]> {
    return await db
      .select()
      .from(analyticReports)
      .where(eq(analyticReports.userId, userId))
      .orderBy(desc(analyticReports.createdAt));
  }

  async getAnalyticReportsByType(userId: number, type: string): Promise<AnalyticReport[]> {
    return await db
      .select()
      .from(analyticReports)
      .where(and(
        eq(analyticReports.userId, userId),
        eq(analyticReports.type, type)
      ))
      .orderBy(desc(analyticReports.createdAt));
  }

  async deleteAnalyticReport(id: number): Promise<boolean> {
    try {
      await db.delete(analyticReports).where(eq(analyticReports.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting analytic report:", error);
      return false;
    }
  }

  // Anomaly Alert methods
  async createAnomalyAlert(insertAlert: InsertAnomalyAlert): Promise<AnomalyAlert> {
    const [alert] = await db
      .insert(anomalyAlerts)
      .values(insertAlert)
      .returning();
    return alert;
  }

  async getAnomalyAlert(id: number): Promise<AnomalyAlert | undefined> {
    const [alert] = await db.select().from(anomalyAlerts).where(eq(anomalyAlerts.id, id));
    return alert || undefined;
  }

  async getAnomalyAlertsByUserId(userId: number): Promise<AnomalyAlert[]> {
    return await db
      .select()
      .from(anomalyAlerts)
      .where(eq(anomalyAlerts.userId, userId))
      .orderBy(desc(anomalyAlerts.createdAt));
  }

  async updateAnomalyAlert(id: number, updates: Partial<InsertAnomalyAlert>): Promise<AnomalyAlert> {
    const [updatedAlert] = await db
      .update(anomalyAlerts)
      .set(updates)
      .where(eq(anomalyAlerts.id, id))
      .returning();
    
    if (!updatedAlert) {
      throw new Error(`Anomaly alert with ID ${id} not found`);
    }
    
    return updatedAlert;
  }

  async getUnreadAnomalyAlertsByUserId(userId: number): Promise<AnomalyAlert[]> {
    return await db
      .select()
      .from(anomalyAlerts)
      .where(and(
        eq(anomalyAlerts.userId, userId),
        eq(anomalyAlerts.isRead, false)
      ))
      .orderBy(desc(anomalyAlerts.createdAt));
  }

  // Goal Updates methods
  async createGoalUpdate(insertUpdate: InsertGoalUpdate): Promise<GoalUpdate> {
    const [update] = await db
      .insert(goalUpdates)
      .values(insertUpdate)
      .returning();
    return update;
  }

  async getGoalUpdate(id: number): Promise<GoalUpdate | undefined> {
    const [update] = await db.select().from(goalUpdates).where(eq(goalUpdates.id, id));
    return update || undefined;
  }

  async getGoalUpdatesByGoalId(goalId: number): Promise<GoalUpdate[]> {
    return await db
      .select()
      .from(goalUpdates)
      .where(eq(goalUpdates.goalId, goalId))
      .orderBy(desc(goalUpdates.updatedAt));
  }

  async getGoalUpdatesByUserId(userId: number): Promise<GoalUpdate[]> {
    return await db
      .select()
      .from(goalUpdates)
      .where(eq(goalUpdates.userId, userId))
      .orderBy(desc(goalUpdates.updatedAt));
  }
}

export const storage = new DatabaseStorage();
