import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import axios from "axios";
import { 
  insertSubscriberSchema, 
  insertBudgetSchema, 
  insertSavingsGoalSchema, 
  insertQuizResultSchema, 
  insertInvestmentSchema,
  insertCourseSchema,
  insertModuleSchema,
  insertLessonSchema,
  insertUserProgressSchema,
  insertTransactionSchema,
  insertAnalyticReportSchema,
  insertAnomalyAlertSchema,
  insertGoalUpdateSchema,
  Transaction,
  SavingsGoal
} from "@shared/schema";

// Helper functions for analytics data processing
function processSpendingCategories(transactions: Transaction[]) {
  const categories: Record<string, number> = {};
  
  transactions.forEach(transaction => {
    if (transaction.amount < 0 && transaction.category) { // Negative amount = spending
      const category = transaction.category;
      categories[category] = (categories[category] || 0) + Math.abs(transaction.amount);
    }
  });
  
  return Object.entries(categories).map(([name, value]) => ({ name, value }));
}

function processMonthlySpending(transactions: Transaction[]) {
  const months: Record<string, number> = {};
  
  transactions.forEach(transaction => {
    if (transaction.amount < 0) { // Negative amount = spending
      const date = new Date(transaction.date);
      const monthKey = date.toLocaleString('default', { month: 'short', year: 'numeric' });
      months[monthKey] = (months[monthKey] || 0) + Math.abs(transaction.amount);
    }
  });
  
  return Object.entries(months).map(([name, amount]) => ({ name, amount }));
}

function processIncomeSources(transactions: Transaction[]) {
  const sources: Record<string, number> = {};
  
  transactions.forEach(transaction => {
    if (transaction.amount > 0 && transaction.category) { // Positive amount = income
      const source = transaction.category;
      sources[source] = (sources[source] || 0) + transaction.amount;
    }
  });
  
  return Object.entries(sources).map(([name, value]) => ({ name, value }));
}

function processIncomeChanges(transactions: Transaction[]) {
  const months: Record<string, number> = {};
  
  transactions.forEach(transaction => {
    if (transaction.amount > 0) { // Positive amount = income
      const date = new Date(transaction.date);
      const monthKey = date.toLocaleString('default', { month: 'short', year: 'numeric' });
      months[monthKey] = (months[monthKey] || 0) + transaction.amount;
    }
  });
  
  return Object.entries(months).map(([name, amount]) => ({ name, amount }));
}

function processInvestmentPerformance(transactions: Transaction[]) {
  // For investment performance, we'd typically need more complex logic
  // Here we're just grouping investment values by month as a simple example
  const months: Record<string, number> = {};
  
  transactions.forEach(transaction => {
    if (transaction.category === 'Investment') {
      const date = new Date(transaction.date);
      const monthKey = date.toLocaleString('default', { month: 'short', year: 'numeric' });
      months[monthKey] = (months[monthKey] || 10000) + transaction.amount; // Starting with base value
    }
  });
  
  return Object.entries(months).map(([name, value]) => ({ name, value }));
}

function processInvestmentAllocation(transactions: Transaction[]) {
  const types: Record<string, number> = {
    'Stocks': 0,
    'Bonds': 0,
    'Real Estate': 0,
    'Crypto': 0,
    'Other': 0
  };
  
  transactions.forEach(transaction => {
    if (transaction.category === 'Investment' && transaction.description) {
      // Try to determine investment type from description
      const desc = transaction.description.toLowerCase();
      if (desc.includes('stock') || desc.includes('equity')) {
        types['Stocks'] += Math.abs(transaction.amount);
      } else if (desc.includes('bond')) {
        types['Bonds'] += Math.abs(transaction.amount);
      } else if (desc.includes('real estate') || desc.includes('property')) {
        types['Real Estate'] += Math.abs(transaction.amount);
      } else if (desc.includes('crypto') || desc.includes('bitcoin') || desc.includes('ethereum')) {
        types['Crypto'] += Math.abs(transaction.amount);
      } else {
        types['Other'] += Math.abs(transaction.amount);
      }
    }
  });
  
  return Object.entries(types).map(([name, value]) => ({ name, value }));
}

function processGoalProgress(goals: SavingsGoal[]) {
  return goals.map(goal => ({
    name: goal.name,
    current: goal.currentAmount,
    remaining: goal.targetAmount - goal.currentAmount
  }));
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  
  // API routes
  const apiRouter = express.Router();
  
  // Financial News routes
  apiRouter.get("/financial-news", async (req, res) => {
    try {
      const { category = "all" } = req.query;
      const apiKey = process.env.ALPHA_VANTAGE_API_KEY;
      
      if (!apiKey) {
        return res.status(500).json({ message: "API key is not configured" });
      }
      
      const response = await axios.get(`https://www.alphavantage.co/query`, {
        params: {
          function: "NEWS_SENTIMENT",
          topics: category !== "all" ? category : undefined,
          sort: "LATEST",
          limit: 12,
          apikey: apiKey
        }
      });
      
      if (response.data && response.data.feed) {
        return res.json(response.data.feed);
      } else {
        return res.status(404).json({ message: "No news articles found" });
      }
    } catch (error) {
      console.error("Error fetching financial news:", error);
      return res.status(500).json({ message: "Failed to fetch financial news", error });
    }
  });
  
  // User routes - needs authentication
  apiRouter.put("/users/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user.id !== parseInt(req.params.id)) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const { fullName, email } = req.body;
      const updates: { fullName?: string; email?: string } = {};
      
      if (fullName !== undefined) {
        updates.fullName = fullName;
      }
      
      if (email !== undefined) {
        // Check if email is already taken
        if (email !== req.user.email) {
          const existingUser = await storage.getUserByEmail(email);
          if (existingUser) {
            return res.status(400).json({ message: "Email already in use" });
          }
        }
        updates.email = email;
      }
      
      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ message: "No valid fields to update" });
      }
      
      const updatedUser = await storage.updateUser(parseInt(req.params.id), updates);
      res.json(updatedUser);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });
  
  // Subscriber routes
  apiRouter.post("/subscribers", async (req, res) => {
    try {
      const validData = insertSubscriberSchema.parse(req.body);
      const subscriber = await storage.createSubscriber(validData);
      res.status(201).json(subscriber);
    } catch (error) {
      res.status(400).json({ message: "Invalid subscriber data", error });
    }
  });

  // Budget routes
  apiRouter.post("/budgets", async (req, res) => {
    try {
      const validData = insertBudgetSchema.parse(req.body);
      const budget = await storage.createBudget(validData);
      res.status(201).json(budget);
    } catch (error) {
      res.status(400).json({ message: "Invalid budget data", error });
    }
  });

  apiRouter.get("/budgets", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const budgets = await storage.getBudgetsByUserId(userId);
      res.json(budgets);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve budgets", error });
    }
  });

  // Savings goal routes
  apiRouter.post("/savings-goals", async (req, res) => {
    try {
      const validData = insertSavingsGoalSchema.parse(req.body);
      const goal = await storage.createSavingsGoal(validData);
      res.status(201).json(goal);
    } catch (error) {
      res.status(400).json({ message: "Invalid savings goal data", error });
    }
  });

  apiRouter.get("/savings-goals", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const goals = await storage.getSavingsGoalsByUserId(userId);
      res.json(goals);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve savings goals", error });
    }
  });

  // Quiz results routes
  apiRouter.post("/quiz-results", async (req, res) => {
    try {
      const validData = insertQuizResultSchema.parse(req.body);
      const quizResult = await storage.createQuizResult(validData);
      res.status(201).json(quizResult);
    } catch (error) {
      res.status(400).json({ message: "Invalid quiz result data", error });
    }
  });

  apiRouter.get("/quiz-results", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const results = await storage.getQuizResultsByUserId(userId);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve quiz results", error });
    }
  });

  // Investment routes
  apiRouter.post("/investments", async (req, res) => {
    try {
      const validData = insertInvestmentSchema.parse(req.body);
      const investment = await storage.createInvestment(validData);
      res.status(201).json(investment);
    } catch (error) {
      res.status(400).json({ message: "Invalid investment data", error });
    }
  });

  apiRouter.get("/investments", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const investments = await storage.getInvestmentsByUserId(userId);
      res.json(investments);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve investments", error });
    }
  });

  apiRouter.get("/investments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid investment ID" });
      }
      const investment = await storage.getInvestment(id);
      if (!investment) {
        return res.status(404).json({ message: "Investment not found" });
      }
      res.json(investment);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve investment", error });
    }
  });

  apiRouter.put("/investments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid investment ID" });
      }
      const validData = insertInvestmentSchema.partial().parse(req.body);
      const updatedInvestment = await storage.updateInvestment(id, validData);
      res.json(updatedInvestment);
    } catch (error) {
      res.status(400).json({ message: "Invalid investment data", error });
    }
  });

  // Course routes
  apiRouter.post("/courses", async (req, res) => {
    try {
      const validData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(validData);
      res.status(201).json(course);
    } catch (error) {
      res.status(400).json({ message: "Invalid course data", error });
    }
  });

  apiRouter.get("/courses", async (req, res) => {
    try {
      const { category, level } = req.query;
      
      if (category) {
        const courses = await storage.getCoursesByCategory(category as string);
        return res.json(courses);
      } else if (level) {
        const courses = await storage.getCoursesByLevel(level as string);
        return res.json(courses);
      } else {
        const courses = await storage.getAllCourses();
        return res.json(courses);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve courses", error });
    }
  });

  apiRouter.get("/courses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid course ID" });
      }
      const course = await storage.getCourse(id);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(course);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve course", error });
    }
  });

  apiRouter.put("/courses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid course ID" });
      }
      const validData = insertCourseSchema.partial().parse(req.body);
      const updatedCourse = await storage.updateCourse(id, validData);
      res.json(updatedCourse);
    } catch (error) {
      res.status(400).json({ message: "Invalid course data", error });
    }
  });

  apiRouter.delete("/courses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid course ID" });
      }
      const success = await storage.deleteCourse(id);
      if (success) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Course not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete course", error });
    }
  });

  // Module routes
  apiRouter.post("/modules", async (req, res) => {
    try {
      const validData = insertModuleSchema.parse(req.body);
      const courseModule = await storage.createModule(validData);
      res.status(201).json(courseModule);
    } catch (error) {
      res.status(400).json({ message: "Invalid module data", error });
    }
  });

  apiRouter.get("/modules/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid module ID" });
      }
      const courseModule = await storage.getModule(id);
      if (!courseModule) {
        return res.status(404).json({ message: "Module not found" });
      }
      res.json(courseModule);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve module", error });
    }
  });

  apiRouter.get("/courses/:courseId/modules", async (req, res) => {
    try {
      const courseId = parseInt(req.params.courseId);
      if (isNaN(courseId)) {
        return res.status(400).json({ message: "Invalid course ID" });
      }
      const courseModules = await storage.getModulesByCourseId(courseId);
      res.json(courseModules);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve modules", error });
    }
  });

  apiRouter.put("/modules/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid module ID" });
      }
      const validData = insertModuleSchema.partial().parse(req.body);
      const updatedModule = await storage.updateModule(id, validData);
      res.json(updatedModule);
    } catch (error) {
      res.status(400).json({ message: "Invalid module data", error });
    }
  });

  apiRouter.delete("/modules/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid module ID" });
      }
      const success = await storage.deleteModule(id);
      if (success) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Module not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete module", error });
    }
  });

  // Lesson routes
  apiRouter.post("/lessons", async (req, res) => {
    try {
      const validData = insertLessonSchema.parse(req.body);
      const lesson = await storage.createLesson(validData);
      res.status(201).json(lesson);
    } catch (error) {
      res.status(400).json({ message: "Invalid lesson data", error });
    }
  });

  apiRouter.get("/lessons/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid lesson ID" });
      }
      const lesson = await storage.getLesson(id);
      if (!lesson) {
        return res.status(404).json({ message: "Lesson not found" });
      }
      res.json(lesson);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve lesson", error });
    }
  });

  apiRouter.get("/modules/:moduleId/lessons", async (req, res) => {
    try {
      const moduleId = parseInt(req.params.moduleId);
      if (isNaN(moduleId)) {
        return res.status(400).json({ message: "Invalid module ID" });
      }
      const lessons = await storage.getLessonsByModuleId(moduleId);
      res.json(lessons);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve lessons", error });
    }
  });

  apiRouter.put("/lessons/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid lesson ID" });
      }
      const validData = insertLessonSchema.partial().parse(req.body);
      const updatedLesson = await storage.updateLesson(id, validData);
      res.json(updatedLesson);
    } catch (error) {
      res.status(400).json({ message: "Invalid lesson data", error });
    }
  });

  apiRouter.delete("/lessons/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid lesson ID" });
      }
      const success = await storage.deleteLesson(id);
      if (success) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Lesson not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete lesson", error });
    }
  });

  // User Progress routes
  apiRouter.post("/progress", async (req, res) => {
    try {
      const validData = insertUserProgressSchema.parse(req.body);
      const progress = await storage.createUserProgress(validData);
      res.status(201).json(progress);
    } catch (error) {
      res.status(400).json({ message: "Invalid progress data", error });
    }
  });

  apiRouter.get("/users/:userId/progress", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const progressData = await storage.getAllUserProgressByUserId(userId);
      res.json(progressData);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve progress data", error });
    }
  });

  apiRouter.put("/progress/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid progress ID" });
      }
      const validData = insertUserProgressSchema.partial().parse(req.body);
      const updatedProgress = await storage.updateUserProgress(id, validData);
      res.json(updatedProgress);
    } catch (error) {
      res.status(400).json({ message: "Invalid progress data", error });
    }
  });

  // Transaction routes
  apiRouter.post("/transactions", async (req, res) => {
    try {
      const validData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(validData);
      res.status(201).json(transaction);
    } catch (error) {
      res.status(400).json({ message: "Invalid transaction data", error });
    }
  });

  apiRouter.get("/transactions", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      const category = req.query.category as string;
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : null;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : null;
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Get transactions by category if specified
      if (category) {
        const transactions = await storage.getTransactionsByCategory(userId, category);
        return res.json(transactions);
      } 
      // Get transactions by date range if specified
      else if (startDate && endDate) {
        const transactions = await storage.getTransactionsByUserIdAndDateRange(userId, startDate, endDate);
        return res.json(transactions);
      } 
      // Get all transactions for user
      else {
        const transactions = await storage.getTransactionsByUserId(userId);
        return res.json(transactions);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve transactions", error });
    }
  });

  apiRouter.get("/transactions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid transaction ID" });
      }
      const transaction = await storage.getTransaction(id);
      if (!transaction) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve transaction", error });
    }
  });

  // Analytics Report routes
  apiRouter.post("/analytics/reports", async (req, res) => {
    try {
      const validData = insertAnalyticReportSchema.parse(req.body);
      const report = await storage.createAnalyticReport(validData);
      res.status(201).json(report);
    } catch (error) {
      res.status(400).json({ message: "Invalid report data", error });
    }
  });

  apiRouter.get("/analytics/reports", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      const type = req.query.type as string;
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      if (type) {
        const reports = await storage.getAnalyticReportsByType(userId, type);
        return res.json(reports);
      } else {
        const reports = await storage.getAnalyticReportsByUserId(userId);
        return res.json(reports);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve reports", error });
    }
  });

  apiRouter.get("/analytics/reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid report ID" });
      }
      const report = await storage.getAnalyticReport(id);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve report", error });
    }
  });

  apiRouter.delete("/analytics/reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid report ID" });
      }
      const success = await storage.deleteAnalyticReport(id);
      if (success) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Report not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete report", error });
    }
  });

  // Anomaly Alerts routes
  apiRouter.post("/analytics/alerts", async (req, res) => {
    try {
      const validData = insertAnomalyAlertSchema.parse(req.body);
      const alert = await storage.createAnomalyAlert(validData);
      res.status(201).json(alert);
    } catch (error) {
      res.status(400).json({ message: "Invalid alert data", error });
    }
  });

  apiRouter.get("/analytics/alerts", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      const unreadOnly = req.query.unreadOnly === 'true';
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      if (unreadOnly) {
        const alerts = await storage.getUnreadAnomalyAlertsByUserId(userId);
        return res.json(alerts);
      } else {
        const alerts = await storage.getAnomalyAlertsByUserId(userId);
        return res.json(alerts);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve alerts", error });
    }
  });

  apiRouter.get("/analytics/alerts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid alert ID" });
      }
      const alert = await storage.getAnomalyAlert(id);
      if (!alert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      res.json(alert);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve alert", error });
    }
  });

  apiRouter.put("/analytics/alerts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid alert ID" });
      }
      const validData = insertAnomalyAlertSchema.partial().parse(req.body);
      const updatedAlert = await storage.updateAnomalyAlert(id, validData);
      res.json(updatedAlert);
    } catch (error) {
      res.status(400).json({ message: "Invalid alert data", error });
    }
  });

  // Goal Updates routes
  apiRouter.post("/goal-updates", async (req, res) => {
    try {
      const validData = insertGoalUpdateSchema.parse(req.body);
      const update = await storage.createGoalUpdate(validData);
      res.status(201).json(update);
    } catch (error) {
      res.status(400).json({ message: "Invalid goal update data", error });
    }
  });

  apiRouter.get("/goal-updates", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      const goalId = req.query.goalId ? parseInt(req.query.goalId as string) : null;
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      if (goalId && !isNaN(goalId)) {
        const updates = await storage.getGoalUpdatesByGoalId(goalId);
        return res.json(updates);
      } else {
        const updates = await storage.getGoalUpdatesByUserId(userId);
        return res.json(updates);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve goal updates", error });
    }
  });

  apiRouter.get("/goal-updates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid goal update ID" });
      }
      const update = await storage.getGoalUpdate(id);
      if (!update) {
        return res.status(404).json({ message: "Goal update not found" });
      }
      res.json(update);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve goal update", error });
    }
  });

  // Analytics routes
  apiRouter.get("/analytics/reports", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const reports = await storage.getAnalyticReportsByUserId(parseInt(userId));
      res.json(reports);
    } catch (error) {
      console.error("Error fetching analytics reports:", error);
      res.status(500).json({ message: "Failed to fetch analytics reports" });
    }
  });
  
  apiRouter.get("/analytics/alerts", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const unreadOnly = req.query.unreadOnly === "true";
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      let alerts;
      if (unreadOnly) {
        alerts = await storage.getUnreadAnomalyAlertsByUserId(parseInt(userId));
      } else {
        alerts = await storage.getAnomalyAlertsByUserId(parseInt(userId));
      }
      
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching anomaly alerts:", error);
      res.status(500).json({ message: "Failed to fetch anomaly alerts" });
    }
  });
  
  apiRouter.post("/analytics/update", async (req, res) => {
    try {
      const { userId, type, chartType, manualValues } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      // Process the update based on the type
      let reportData: any = {};
      
      if (manualValues) {
        // Use manually entered values
        reportData = {
          manualEntry: true,
          chartType,
          values: manualValues
        };
      } else {
        // Generate data based on past analytics or default data
        reportData = {
          chartType,
          generatedAt: new Date().toISOString(),
          // Include different data structures based on type
          ...(type === 'spending' && {
            categoryData: [
              { name: 'Housing', value: 1200 },
              { name: 'Food', value: 450 },
              { name: 'Transportation', value: 300 },
              { name: 'Entertainment', value: 150 },
              { name: 'Utilities', value: 200 },
              { name: 'Healthcare', value: 100 }
            ],
            monthlyData: Array.from({ length: 6 }, (_, i) => ({
              name: new Date(Date.now() - (5-i) * 30 * 24 * 60 * 60 * 1000).toLocaleString('default', { month: 'short' }),
              amount: 2000 + Math.round(Math.random() * 1000)
            }))
          }),
          ...(type === 'income' && {
            sourceData: [
              { name: 'Salary', value: 3500 },
              { name: 'Investments', value: 500 },
              { name: 'Side Hustle', value: 300 }
            ],
            trendData: Array.from({ length: 6 }, (_, i) => ({
              name: new Date(Date.now() - (5-i) * 30 * 24 * 60 * 60 * 1000).toLocaleString('default', { month: 'short' }),
              amount: 4000 + Math.round(Math.random() * 500)
            }))
          }),
          ...(type === 'investment' && {
            performanceData: Array.from({ length: 6 }, (_, i) => ({
              name: new Date(Date.now() - (5-i) * 30 * 24 * 60 * 60 * 1000).toLocaleString('default', { month: 'short' }),
              value: 10000 + (i * 200) + Math.round(Math.random() * 300)
            })),
            allocationData: [
              { name: 'Stocks', value: 6000 },
              { name: 'Bonds', value: 2500 },
              { name: 'Real Estate', value: 1500 },
              { name: 'Crypto', value: 500 }
            ]
          }),
          ...(type === 'goal' && {
            progressData: [
              { name: 'Emergency Fund', current: 3000, remaining: 2000 },
              { name: 'Vacation', current: 1500, remaining: 500 },
              { name: 'Down Payment', current: 15000, remaining: 35000 }
            ]
          })
        };
      }
      
      // Create a new analytic report
      const validData = insertAnalyticReportSchema.parse({
        userId: parseInt(userId),
        type,
        data: reportData,
        createdAt: new Date()
      });
      
      const report = await storage.createAnalyticReport(validData);
      res.status(201).json(report);
    } catch (error) {
      console.error("Error updating analytics:", error);
      res.status(500).json({ message: "Failed to update analytics" });
    }
  });

  // Register API routes
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
