import { pgTable, text, serial, integer, boolean, json, timestamp, real, varchar, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
});

// Budget entry schema
export const budgets = pgTable("budgets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  income: integer("income").notNull(),
  // Needs categories (50%)
  housing: integer("housing").default(0),
  utilities: integer("utilities").default(0),
  groceries: integer("groceries").default(0),
  transportation: integer("transportation").default(0),
  healthcare: integer("healthcare").default(0),
  debt: integer("debt").default(0),
  // Wants categories (30%)
  subscriptions: integer("subscriptions").default(0),
  entertainment: integer("entertainment").default(0),
  dining: integer("dining").default(0),
  shopping: integer("shopping").default(0),
  travel: integer("travel").default(0),
  miscellaneous: integer("miscellaneous").default(0),
  // Savings categories (20%)
  savings: integer("savings").default(0),
  investments: integer("investments").default(0),
  education: integer("education").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBudgetSchema = createInsertSchema(budgets).pick({
  userId: true,
  income: true,
  housing: true,
  utilities: true,
  groceries: true,
  transportation: true,
  healthcare: true,
  debt: true,
  subscriptions: true,
  entertainment: true,
  dining: true,
  shopping: true,
  travel: true,
  miscellaneous: true,
  savings: true,
  investments: true,
  education: true,
});

// Savings goal schema
export const savingsGoals = pgTable("savings_goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  targetAmount: integer("target_amount").notNull(),
  currentAmount: integer("current_amount").notNull(),
  targetDate: timestamp("target_date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSavingsGoalSchema = createInsertSchema(savingsGoals).pick({
  userId: true,
  name: true,
  targetAmount: true,
  currentAmount: true,
  targetDate: true,
});

// Investment options schema
export const investments = pgTable("investments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  currencyCode: text("currency_code").notNull(),
  amount: real("amount").notNull(),
  exchangeRate: real("exchange_rate").notNull(),
  targetCurrency: text("target_currency").notNull(),
  estimatedReturn: real("estimated_return").notNull(),
  riskLevel: text("risk_level").notNull(),
  investmentDate: timestamp("investment_date").defaultNow(),
  maturityDate: timestamp("maturity_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInvestmentSchema = createInsertSchema(investments).pick({
  userId: true,
  currencyCode: true,
  amount: true,
  exchangeRate: true,
  targetCurrency: true,
  estimatedReturn: true,
  riskLevel: true,
  maturityDate: true,
});

// Quiz results schema
export const quizResults = pgTable("quiz_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  score: integer("score").notNull(),
  answers: json("answers").notNull(), // Array of answers
  recommendations: json("recommendations").notNull(), // Array of recommendations
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertQuizResultSchema = createInsertSchema(quizResults).pick({
  userId: true,
  score: true,
  answers: true,
  recommendations: true,
});

// Newsletter subscribers schema
export const subscribers = pgTable("subscribers", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSubscriberSchema = createInsertSchema(subscribers).pick({
  email: true,
});

// Courses schema
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  level: varchar("level", { length: 50 }).notNull(), // Beginner, Intermediate, Advanced
  category: varchar("category", { length: 100 }).notNull(),
  imageUrl: text("image_url"),
  thumbnailUrl: text("thumbnail_url"), // Higher quality thumbnail for display
  durationMinutes: integer("duration_minutes").notNull(),
  instructor: varchar("instructor", { length: 100 }),
  tags: text("tags").array(), // For additional categorization and filtering
  featured: boolean("featured").default(false), // For highlighting recommended courses
  popularity: integer("popularity").default(0), // For sorting courses by popularity
  averageRating: real("average_rating"), // Course rating
  enrollmentCount: integer("enrollment_count").default(0), // Number of students enrolled
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCourseSchema = createInsertSchema(courses).pick({
  title: true,
  description: true,
  level: true,
  category: true,
  imageUrl: true,
  thumbnailUrl: true,
  durationMinutes: true,
  instructor: true,
  tags: true,
  featured: true,
});

// Course modules schema
export const modules = pgTable("modules", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  order: integer("order").notNull(), // To maintain module sequence
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertModuleSchema = createInsertSchema(modules).pick({
  courseId: true,
  title: true,
  description: true,
  order: true,
});

// Lessons schema
export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  moduleId: integer("module_id").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  order: integer("order").notNull(), // To maintain lesson sequence
  durationMinutes: integer("duration_minutes").notNull(),
  videoUrl: text("video_url"), // Optional video content
  thumbnailUrl: text("thumbnail_url"), // Thumbnail image for video
  difficulty: varchar("difficulty", { length: 50 }), // Beginner, Intermediate, Advanced
  tags: text("tags").array(), // For additional categorization
  isVideoLesson: boolean("is_video_lesson").default(false),
  hasQuiz: boolean("has_quiz").default(false),
  quizData: json("quiz_data"), // Quiz questions and answers in JSON format
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertLessonSchema = createInsertSchema(lessons).pick({
  moduleId: true,
  title: true,
  content: true,
  order: true,
  durationMinutes: true,
  videoUrl: true,
  thumbnailUrl: true,
  difficulty: true,
  tags: true,
  isVideoLesson: true,
  hasQuiz: true,
  quizData: true,
});

// User course progress schema
export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  courseId: integer("course_id").notNull(),
  moduleId: integer("module_id"),
  lessonId: integer("lesson_id"),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
  quizScore: integer("quiz_score"),
  lastAccessedAt: timestamp("last_accessed_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserProgressSchema = createInsertSchema(userProgress).pick({
  userId: true,
  courseId: true,
  moduleId: true,
  lessonId: true,
  completed: true,
  completedAt: true,
  quizScore: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Budget = typeof budgets.$inferSelect;
export type InsertBudget = z.infer<typeof insertBudgetSchema>;

export type SavingsGoal = typeof savingsGoals.$inferSelect;
export type InsertSavingsGoal = z.infer<typeof insertSavingsGoalSchema>;

export type Investment = typeof investments.$inferSelect;
export type InsertInvestment = z.infer<typeof insertInvestmentSchema>;

export type QuizResult = typeof quizResults.$inferSelect;
export type InsertQuizResult = z.infer<typeof insertQuizResultSchema>;

export type Subscriber = typeof subscribers.$inferSelect;
export type InsertSubscriber = z.infer<typeof insertSubscriberSchema>;

export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;

export type Module = typeof modules.$inferSelect;
export type InsertModule = z.infer<typeof insertModuleSchema>;

export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = z.infer<typeof insertLessonSchema>;

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;

// Transactions schema (for spending analysis and anomaly detection)
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: real("amount").notNull(),
  type: varchar("type", { length: 50 }).notNull(), // income, expense, transfer
  category: varchar("category", { length: 100 }).notNull(), // food, utilities, entertainment, etc.
  description: text("description"),
  merchant: text("merchant"),
  date: date("date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  userId: true,
  amount: true,
  type: true,
  category: true,
  description: true,
  merchant: true,
  date: true,
});

// Analytics Reports schema
export const analyticReports = pgTable("analytic_reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(), // spending, investment, goal, tax
  dateRange: json("date_range").notNull(), // { start: Date, end: Date }
  data: json("data").notNull(), // Chart and report data
  insights: json("insights"), // AI-generated insights about the data
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAnalyticReportSchema = createInsertSchema(analyticReports).pick({
  userId: true,
  title: true,
  type: true,
  dateRange: true,
  data: true,
  insights: true,
});

// Anomaly Detection schema
export const anomalyAlerts = pgTable("anomaly_alerts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: varchar("type", { length: 50 }).notNull(), // spending_spike, unusual_activity, goal_deviation
  severity: varchar("severity", { length: 20 }).notNull(), // low, medium, high
  description: text("description").notNull(),
  data: json("data").notNull(), // Details about the anomaly
  isRead: boolean("is_read").default(false),
  isResolved: boolean("is_resolved").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAnomalyAlertSchema = createInsertSchema(anomalyAlerts).pick({
  userId: true,
  type: true,
  severity: true,
  description: true,
  data: true,
  isRead: true,
  isResolved: true,
});

// Goal Tracking Updates schema
export const goalUpdates = pgTable("goal_updates", {
  id: serial("id").primaryKey(),
  goalId: integer("goal_id").notNull(),
  userId: integer("user_id").notNull(),
  previousAmount: real("previous_amount").notNull(),
  newAmount: real("new_amount").notNull(),
  changeAmount: real("change_amount").notNull(),
  note: text("note"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertGoalUpdateSchema = createInsertSchema(goalUpdates).pick({
  goalId: true,
  userId: true,
  previousAmount: true,
  newAmount: true,
  changeAmount: true,
  note: true,
});

// Additional type exports for new schemas
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type AnalyticReport = typeof analyticReports.$inferSelect;
export type InsertAnalyticReport = z.infer<typeof insertAnalyticReportSchema>;

export type AnomalyAlert = typeof anomalyAlerts.$inferSelect;
export type InsertAnomalyAlert = z.infer<typeof insertAnomalyAlertSchema>;

export type GoalUpdate = typeof goalUpdates.$inferSelect;
export type InsertGoalUpdate = z.infer<typeof insertGoalUpdateSchema>;
