import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { GraduationCap, Calculator, Target, ArrowRight, PiggyBank, BookOpen, ChevronDown } from "lucide-react";
import LearningResources from "@/components/LearningResources";
import NewsletterSignup from "@/components/NewsletterSignup";
import FinancialHealthQuiz from "@/components/FinancialHealthQuiz";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const Home = () => {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [showQuiz, setShowQuiz] = useState(false);
  
  // Function to handle smooth scrolling to element
  const scrollToElement = (elementId: string) => {
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Function to handle authentication check before navigation
  const handleAuthenticatedNavigation = (path: string) => {
    if (user) {
      setLocation(path);
    } else {
      // Store the path for redirection after login
      sessionStorage.setItem('redirectTo', path);
      setLocation('/auth');
    }
  };

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary to-indigo-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-12 lg:gap-8">
            <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
              <h1 className="mt-4 text-4xl tracking-tight font-extrabold text-white sm:mt-5 sm:text-5xl lg:mt-6">
                <span className="block">Financial Technology</span>
                <span className="block text-green-300">For Everyone</span>
              </h1>
              <p className="mt-3 text-base text-white sm:mt-5 sm:text-xl lg:text-lg xl:text-xl">
                We're on a mission to help you better understand money, save smarter, and access financial services easily.
              </p>
              <div className="mt-8 sm:max-w-lg flex flex-col sm:flex-row justify-center lg:justify-start">
                <motion.div 
                  className="rounded-md shadow"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <Button 
                    className="w-full py-6 px-8 bg-white text-primary hover:bg-neutral-50 text-lg font-semibold"
                    onClick={() => handleAuthenticatedNavigation('/tools')}
                  >
                    Get Started 
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </motion.div>
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <Button 
                    variant="outline" 
                    className="w-full py-3 px-5 bg-primary/20 text-white border-white hover:bg-primary/30"
                    onClick={() => scrollToElement("learn-more")}
                  >
                    Learn More
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
            <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
              <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
                <img
                  className="w-full rounded-lg"
                  src="https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
                  alt="Person using financial app on smartphone"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bottom-5 left-0 right-0 flex justify-center">
          <button 
            onClick={() => scrollToElement("learn-more")}
            className="animate-bounce rounded-full bg-white p-3 shadow-lg"
          >
            <ChevronDown className="h-6 w-6 text-primary" />
          </button>
        </div>
      </section>

      {/* Financial Health Quiz Section - Now Featured Prominently */}
      <section className="py-14 bg-gradient-to-b from-white to-neutral-50 dark:from-gray-900 dark:to-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-base font-semibold text-primary dark:text-primary-400 uppercase tracking-wide">Self Assessment</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 dark:text-white sm:text-4xl">
              What's Your Financial Health Score?
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 dark:text-gray-300 mx-auto">
              Take our quick 2-minute quiz to get personalized insights and recommendations.
            </p>
          </div>
          
          <div className="flex justify-center">
            <Dialog open={showQuiz} onOpenChange={setShowQuiz}>
              <DialogTrigger asChild>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    size="lg" 
                    className="py-6 px-8 text-lg font-medium"
                  >
                    Start Financial Health Quiz
                  </Button>
                </motion.div>
              </DialogTrigger>
              <DialogContent className="sm:max-w-3xl">
                <DialogHeader>
                  <DialogTitle>Financial Health Assessment</DialogTitle>
                  <DialogDescription>
                    Answer a few questions to get personalized recommendations for your financial journey.
                  </DialogDescription>
                </DialogHeader>
                <FinancialHealthQuiz />
              </DialogContent>
            </Dialog>
          </div>
          
          <div className="mt-8 max-w-3xl mx-auto grid grid-cols-1 gap-8 sm:grid-cols-2">
            <div className="border border-neutral-200 dark:border-gray-700 rounded-lg p-6 bg-white dark:bg-gray-800 shadow-sm">
              <div className="flex items-center mb-4">
                <div className="flex-shrink-0 bg-green-100 dark:bg-green-900 rounded-full p-3">
                  <PiggyBank className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="ml-4 text-lg font-medium text-neutral-900 dark:text-white">Personalized Recommendations</h3>
              </div>
              <p className="text-neutral-600 dark:text-gray-300">
                Get tailored advice based on your specific financial situation and goals.
              </p>
            </div>
            
            <div className="border border-neutral-200 dark:border-gray-700 rounded-lg p-6 bg-white dark:bg-gray-800 shadow-sm">
              <div className="flex items-center mb-4">
                <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900 rounded-full p-3">
                  <BookOpen className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="ml-4 text-lg font-medium text-neutral-900 dark:text-white">Actionable Steps</h3>
              </div>
              <p className="text-neutral-600 dark:text-gray-300">
                Learn practical steps you can take immediately to improve your financial well-being.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="learn-more" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base font-semibold text-primary uppercase tracking-wide">Our Approach</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 sm:text-4xl">
              Simplifying Finance For Everyone
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 mx-auto">
              We break down complex financial concepts into simple, actionable steps.
            </p>
          </div>

          <div className="mt-12">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              <div className="pt-6">
                <div className="flow-root bg-white rounded-lg px-6 pb-8 shadow-sm hover:shadow-md h-full transition-all duration-200 hover:-translate-y-1">
                  <div className="-mt-6">
                    <div>
                      <span className="inline-flex items-center justify-center p-3 bg-primary rounded-md shadow-lg">
                        <GraduationCap className="h-6 w-6 text-white" />
                      </span>
                    </div>
                    <h3 className="mt-8 text-lg font-medium text-neutral-900 tracking-tight">Learn Financial Basics</h3>
                    <p className="mt-5 text-base text-neutral-500">
                      Build a strong foundation with our simple guides on budgeting, saving, investing, and more.
                    </p>
                    <div className="mt-6">
                      <Button 
                        variant="link" 
                        className="text-primary p-0"
                        onClick={() => handleAuthenticatedNavigation('/learn')}
                      >
                        Explore Learning Resources <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-6">
                <div className="flow-root bg-white rounded-lg px-6 pb-8 shadow-sm hover:shadow-md h-full transition-all duration-200 hover:-translate-y-1">
                  <div className="-mt-6">
                    <div>
                      <span className="inline-flex items-center justify-center p-3 bg-green-500 rounded-md shadow-lg">
                        <Calculator className="h-6 w-6 text-white" />
                      </span>
                    </div>
                    <h3 className="mt-8 text-lg font-medium text-neutral-900 tracking-tight">Smart Budgeting Tools</h3>
                    <p className="mt-5 text-base text-neutral-500">
                      Use our interactive calculators to plan your budget, track expenses, and meet your financial goals.
                    </p>
                    <div className="mt-6">
                      <Button 
                        variant="link" 
                        className="text-green-600 p-0"
                        onClick={() => handleAuthenticatedNavigation('/tools')}
                      >
                        Try Financial Tools <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-6">
                <div className="flow-root bg-white rounded-lg px-6 pb-8 shadow-sm hover:shadow-md h-full transition-all duration-200 hover:-translate-y-1">
                  <div className="-mt-6">
                    <div>
                      <span className="inline-flex items-center justify-center p-3 bg-indigo-500 rounded-md shadow-lg">
                        <Target className="h-6 w-6 text-white" />
                      </span>
                    </div>
                    <h3 className="mt-8 text-lg font-medium text-neutral-900 tracking-tight">Goal Setting</h3>
                    <p className="mt-5 text-base text-neutral-500">
                      Set savings goals, track your progress, and celebrate your financial wins along the way.
                    </p>
                    <div className="mt-6">
                      <Button 
                        variant="link" 
                        className="text-indigo-600 p-0"
                        onClick={() => handleAuthenticatedNavigation('/tools#savings-goal-tracker')}
                      >
                        Set a Savings Goal <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Learning Resources Section */}
      <section id="learn" className="py-16 bg-neutral-50">
        <LearningResources limit={3} />
      </section>

      {/* Newsletter Section */}
      <NewsletterSignup />
    </div>
  );
};

export default Home;
