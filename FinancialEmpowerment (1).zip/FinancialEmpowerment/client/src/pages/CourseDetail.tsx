import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Clock, Book, CheckCircle, Play, FileText, HelpCircle } from "lucide-react";

import type { CourseData, ModuleData, LessonData } from "@/lib/types";

interface CourseDetailProps {
  params: {
    id: string;
  };
}

export default function CourseDetail({ params }: CourseDetailProps) {
  const [, setLocation] = useLocation();
  const courseId = parseInt(params.id);
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedModuleId, setSelectedModuleId] = useState<number | null>(null);
  const [selectedLessonId, setSelectedLessonId] = useState<number | null>(null);

  const courseQuery = useQuery({
    queryKey: ["/api/courses", courseId],
    queryFn: async () => {
      const response = await fetch(`/api/courses/${courseId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch course");
      }
      return response.json() as Promise<CourseData>;
    }
  });

  const modulesQuery = useQuery({
    queryKey: ["/api/courses", courseId, "modules"],
    queryFn: async () => {
      const response = await fetch(`/api/courses/${courseId}/modules`);
      if (!response.ok) {
        throw new Error("Failed to fetch modules");
      }
      return response.json() as Promise<ModuleData[]>;
    },
    enabled: !courseQuery.isLoading && !!courseId
  });

  const lessonsQuery = useQuery({
    queryKey: ["/api/modules", selectedModuleId, "lessons"],
    queryFn: async () => {
      if (!selectedModuleId) return [];
      const response = await fetch(`/api/modules/${selectedModuleId}/lessons`);
      if (!response.ok) {
        throw new Error("Failed to fetch lessons");
      }
      return response.json() as Promise<LessonData[]>;
    },
    enabled: !!selectedModuleId
  });

  const lessonQuery = useQuery({
    queryKey: ["/api/lessons", selectedLessonId],
    queryFn: async () => {
      if (!selectedLessonId) return null;
      const response = await fetch(`/api/lessons/${selectedLessonId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch lesson");
      }
      return response.json() as Promise<LessonData>;
    },
    enabled: !!selectedLessonId
  });

  const handleModuleSelect = (moduleId: number) => {
    setSelectedModuleId(moduleId);
    setActiveTab("curriculum");
  };

  const handleLessonSelect = (lessonId: number) => {
    setSelectedLessonId(lessonId);
    setActiveTab("lesson");
  };

  const handleBack = () => {
    if (activeTab === "lesson") {
      setActiveTab("curriculum");
      setSelectedLessonId(null);
    } else if (activeTab === "curriculum" && selectedModuleId) {
      setActiveTab("overview");
      setSelectedModuleId(null);
    } else {
      setLocation("/courses");
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Beginner":
        return "bg-green-100 text-green-800";
      case "Intermediate":
        return "bg-blue-100 text-blue-800";
      case "Advanced":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getLessonIcon = (lesson: LessonData) => {
    if (lesson.videoUrl) {
      return <Play size={18} className="mr-2 text-blue-500" />;
    } else if (lesson.hasQuiz) {
      return <HelpCircle size={18} className="mr-2 text-purple-500" />;
    } else {
      return <FileText size={18} className="mr-2 text-gray-500" />;
    }
  };

  if (courseQuery.isLoading) {
    return (
      <div className="container mx-auto py-8 px-4 md:px-6">
        <Button variant="ghost" onClick={handleBack} className="mb-6">
          <ArrowLeft size={16} className="mr-2" /> Back
        </Button>
        <div className="mb-8">
          <Skeleton className="h-10 w-3/4 mb-4" />
          <Skeleton className="h-6 w-1/2 mb-2" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4 mt-2" />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Skeleton className="h-64 w-full mb-6" />
            <Skeleton className="h-8 w-1/3 mb-4" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-3/4" />
          </div>
          <div>
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (courseQuery.isError) {
    return (
      <div className="container mx-auto py-8 px-4 md:px-6 text-center">
        <Button variant="ghost" onClick={() => setLocation("/courses")} className="mb-6">
          <ArrowLeft size={16} className="mr-2" /> Back to Courses
        </Button>
        <h2 className="text-2xl font-bold text-red-500 mb-4">Error Loading Course</h2>
        <p className="mb-6">We couldn't load the course details. Please try again.</p>
        <Button onClick={() => courseQuery.refetch()}>Retry</Button>
      </div>
    );
  }

  if (!courseQuery.data) {
    return (
      <div className="container mx-auto py-8 px-4 md:px-6 text-center">
        <Button variant="ghost" onClick={() => setLocation("/courses")} className="mb-6">
          <ArrowLeft size={16} className="mr-2" /> Back to Courses
        </Button>
        <h2 className="text-2xl font-bold mb-4">Course Not Found</h2>
        <p className="mb-6">The course you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => setLocation("/courses")}>Browse Courses</Button>
      </div>
    );
  }

  const course = courseQuery.data;
  const modules = modulesQuery.data || [];
  const lessons = lessonsQuery.data || [];
  const currentLesson = lessonQuery.data;

  // Calculate total course duration
  const totalDuration = modules.reduce((total, module) => {
    const moduleDuration = (module.lessons || []).reduce(
      (moduleTotal, lesson) => moduleTotal + (lesson.durationMinutes || 0),
      0
    );
    return total + moduleDuration;
  }, 0);

  return (
    <div className="container mx-auto py-8 px-4 md:px-6">
      <Button variant="ghost" onClick={handleBack} className="mb-6">
        <ArrowLeft size={16} className="mr-2" /> 
        {activeTab === "overview" ? "Back to Courses" : 
         activeTab === "curriculum" ? "Back to Overview" : 
         "Back to Curriculum"}
      </Button>

      {activeTab === "overview" && (
        <>
          <div className="mb-8">
            <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-500 to-teal-400 text-transparent bg-clip-text">
                {course.title}
              </h1>
              <Badge className={getLevelColor(course.level)}>
                {course.level}
              </Badge>
            </div>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
              <div className="flex items-center">
                <Clock size={16} className="mr-1" />
                <span>{course.durationMinutes || totalDuration} minutes</span>
              </div>
              <div className="flex items-center">
                <Book size={16} className="mr-1" />
                <span>{modules.length} modules</span>
              </div>
              <Badge variant="outline">{course.category}</Badge>
            </div>
            <p className="text-gray-600">{course.description}</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold mb-4">What You'll Learn</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-8">
                {/* Learning objectives would be dynamically generated */}
                <div className="flex items-start">
                  <CheckCircle size={20} className="mr-2 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Understand the fundamentals of personal finance</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={20} className="mr-2 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Create and maintain a sustainable budget</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={20} className="mr-2 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Build strategies for debt reduction</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle size={20} className="mr-2 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Set achievable financial goals</span>
                </div>
              </div>

              <h2 className="text-2xl font-bold mb-4">Course Content</h2>
              {modulesQuery.isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : (
                <Accordion type="single" collapsible className="mb-8">
                  {modules.map((module, index) => (
                    <AccordionItem key={module.id} value={`module-${module.id}`}>
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex flex-col items-start text-left">
                          <div className="font-medium">Module {index + 1}: {module.title}</div>
                          <div className="text-sm text-gray-500">
                            {module.lessons?.length || 0} lessons
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <p className="mb-3 text-gray-600">{module.description}</p>
                        <Button onClick={() => handleModuleSelect(module.id)}>
                          View Module
                        </Button>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </div>

            <div>
              <Card className="sticky top-4">
                <CardHeader className="bg-gradient-to-r from-blue-500 to-teal-400 text-white">
                  <CardTitle>Course Progress</CardTitle>
                  <CardDescription className="text-white text-opacity-80">
                    Track your learning journey
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="mb-6">
                    <div className="flex justify-between mb-2 text-sm">
                      <span>Overall Progress</span>
                      <span>0%</span>
                    </div>
                    <Progress value={0} className="h-2" />
                  </div>
                  <Button className="w-full mb-4" onClick={() => setActiveTab("curriculum")}>
                    Start Learning
                  </Button>
                  <div className="text-center text-xs text-gray-500">
                    {modules.length} modules • {lessons.length} lessons
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </>
      )}

      {activeTab === "curriculum" && (
        <div>
          <h1 className="text-2xl md:text-3xl font-bold mb-6">
            {selectedModuleId && modules.find(m => m.id === selectedModuleId)?.title || "Curriculum"}
          </h1>

          {lessonsQuery.isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {lessons.map((lesson, index) => (
                <Card 
                  key={lesson.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => handleLessonSelect(lesson.id)}
                >
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="mr-3 text-lg font-medium text-gray-500">
                        {index + 1}
                      </div>
                      <div>
                        <div className="flex items-center">
                          {getLessonIcon(lesson)}
                          <h3 className="font-medium">{lesson.title}</h3>
                        </div>
                        <div className="text-sm text-gray-500 flex items-center mt-1">
                          <Clock size={14} className="mr-1" />
                          {lesson.durationMinutes} min
                        </div>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Play size={18} />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === "lesson" && currentLesson && (
        <div>
          <h1 className="text-2xl md:text-3xl font-bold mb-4">{currentLesson.title}</h1>
          <div className="flex items-center text-sm text-gray-500 mb-6">
            <Clock size={16} className="mr-1" />
            <span>{currentLesson.durationMinutes} minutes</span>
            {currentLesson.videoUrl && (
              <Badge variant="outline" className="ml-3">Video Lesson</Badge>
            )}
            {currentLesson.hasQuiz && (
              <Badge variant="outline" className="ml-3">Includes Quiz</Badge>
            )}
          </div>

          <Tabs defaultValue="content" className="mb-8">
            <TabsList>
              <TabsTrigger value="content">Lesson Content</TabsTrigger>
              {currentLesson.hasQuiz && (
                <TabsTrigger value="quiz">Quiz</TabsTrigger>
              )}
              <TabsTrigger value="notes">Notes</TabsTrigger>
            </TabsList>
            <TabsContent value="content" className="mt-6">
              {currentLesson.videoUrl && (
                <div className="aspect-video bg-gray-100 mb-6 flex items-center justify-center">
                  <div className="text-gray-500">Video content would be displayed here</div>
                </div>
              )}
              <div className="prose max-w-none">
                <div dangerouslySetInnerHTML={{ __html: currentLesson.content }} />
              </div>
            </TabsContent>
            {currentLesson.hasQuiz && (
              <TabsContent value="quiz" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Knowledge Check</CardTitle>
                    <CardDescription>
                      Test your understanding of the material covered in this lesson.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <p className="text-center text-gray-500">
                        Quiz content would be displayed here
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            )}
            <TabsContent value="notes" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Your Notes</CardTitle>
                  <CardDescription>
                    Take notes to help reinforce the material.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <textarea 
                    className="w-full h-64 p-4 border rounded-md" 
                    placeholder="Type your notes here..."
                  />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="flex justify-between">
            <Button variant="outline" onClick={() => setActiveTab("curriculum")}>
              <ArrowLeft size={16} className="mr-2" /> Back to Lessons
            </Button>
            <Button>
              Mark as Complete <CheckCircle size={16} className="ml-2" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}