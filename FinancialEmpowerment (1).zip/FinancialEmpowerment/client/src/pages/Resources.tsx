import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import NewsletterSignup from "@/components/NewsletterSignup";
import FinancialNews from "@/components/FinancialNews";
import BudgetCalculator from "@/components/BudgetCalculator";

const Resources = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-neutral-50 dark:bg-gray-800 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-extrabold text-neutral-900 dark:text-white sm:text-5xl sm:tracking-tight lg:text-6xl">
              Resources
            </h1>
            <p className="mt-5 text-xl text-neutral-500 dark:text-gray-300">
              Find helpful resources, tools, and information to support your financial journey.
            </p>
          </div>
        </div>
      </section>

      {/* External Resources Section */}
      <section id="external-resources" className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base font-semibold text-primary dark:text-primary-400 uppercase tracking-wide">Additional Resources</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 dark:text-white sm:text-4xl">
              Helpful External Resources
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 dark:text-gray-300 mx-auto">
              Additional trusted resources to support your financial education.
            </p>
          </div>

          <div className="mt-12 grid gap-5 max-w-lg mx-auto lg:grid-cols-3 lg:max-w-none">
            <Card className="flex flex-col overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-1 dark:bg-gray-800 dark:border-gray-700">
              <CardContent className="flex-1 p-6">
                <div className="flex-1">
                  <p className="text-sm font-medium text-primary dark:text-primary-400">Government Resources</p>
                  <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mt-2">Consumer Financial Protection Bureau</h3>
                  <p className="mt-3 text-base text-neutral-500 dark:text-gray-300">
                    Reliable information about consumer financial products and services, and tools to help you make financial decisions.
                  </p>
                </div>
                <div className="mt-6">
                  <a href="https://www.consumerfinance.gov/" target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" className="text-primary dark:text-primary-400 border-neutral-300 dark:border-gray-600 hover:bg-neutral-50 dark:hover:bg-gray-700">
                      Visit Website
                    </Button>
                  </a>
                </div>
              </CardContent>
            </Card>

            <Card className="flex flex-col overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-1 dark:bg-gray-800 dark:border-gray-700">
              <CardContent className="flex-1 p-6">
                <div className="flex-1">
                  <p className="text-sm font-medium text-primary dark:text-primary-400">Financial Education</p>
                  <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mt-2">Khan Academy: Personal Finance</h3>
                  <p className="mt-3 text-base text-neutral-500 dark:text-gray-300">
                    Free courses covering a wide range of personal finance topics, from budgeting to investing.
                  </p>
                </div>
                <div className="mt-6">
                  <a href="https://www.khanacademy.org/college-careers-more/personal-finance" target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" className="text-primary dark:text-primary-400 border-neutral-300 dark:border-gray-600 hover:bg-neutral-50 dark:hover:bg-gray-700">
                      Visit Website
                    </Button>
                  </a>
                </div>
              </CardContent>
            </Card>

            <Card className="flex flex-col overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-1 dark:bg-gray-800 dark:border-gray-700">
              <CardContent className="flex-1 p-6">
                <div className="flex-1">
                  <p className="text-sm font-medium text-primary dark:text-primary-400">Retirement Planning</p>
                  <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mt-2">Social Security Administration</h3>
                  <p className="mt-3 text-base text-neutral-500 dark:text-gray-300">
                    Official information about Social Security benefits and retirement planning resources.
                  </p>
                </div>
                <div className="mt-6">
                  <a href="https://www.ssa.gov/" target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" className="text-primary dark:text-primary-400 border-neutral-300 dark:border-gray-600 hover:bg-neutral-50 dark:hover:bg-gray-700">
                      Visit Website
                    </Button>
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Financial News Section */}
      <section id="financial-news" className="py-16 bg-neutral-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-base font-semibold text-primary dark:text-primary-400 uppercase tracking-wide">Financial News</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 dark:text-white sm:text-4xl">
              Latest Financial Updates
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 dark:text-gray-300 mx-auto">
              Stay informed with the latest news and developments in the financial world.
            </p>
          </div>
          <FinancialNews />
        </div>
      </section>
      
      {/* About Section */}
      <section id="about" className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center">
            <h2 className="text-base font-semibold text-primary dark:text-primary-400 uppercase tracking-wide">About Us</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 dark:text-white sm:text-4xl">
              Our Mission
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 dark:text-gray-300 lg:mx-auto">
              FinSmart is dedicated to making financial knowledge and tools accessible to everyone, 
              regardless of their background or current financial situation.
            </p>
          </div>

          <div className="mt-10">
            <div className="prose prose-blue dark:prose-invert mx-auto lg:max-w-none">
              <p className="text-neutral-700 dark:text-gray-300">
                We believe that financial literacy is a fundamental skill that everyone deserves to have. 
                Our platform provides jargon-free education, interactive tools, and practical resources to help 
                people make informed financial decisions and build a more secure future.
              </p>
              <p className="text-neutral-700 dark:text-gray-300">
                Founded in 2023, FinSmart came from a simple observation: many people feel overwhelmed and 
                underprepared when it comes to managing their money. We set out to change that by creating a 
                platform that breaks down complex financial concepts into simple, actionable steps.
              </p>
              <p className="text-neutral-700 dark:text-gray-300">
                Our team consists of financial educators, technology experts, and design specialists who are 
                passionate about democratizing financial knowledge and empowering people to take control of 
                their financial lives.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQs Section */}
      <section id="faqs" className="py-16 bg-neutral-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base font-semibold text-primary dark:text-primary-400 uppercase tracking-wide">FAQs</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 dark:text-white sm:text-4xl">
              Frequently Asked Questions
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 dark:text-gray-300 mx-auto">
              Find answers to common questions about our platform and financial topics.
            </p>
          </div>

          <div className="mt-12 max-w-4xl mx-auto">
            <div className="bg-white dark:bg-gray-900 shadow overflow-hidden sm:rounded-lg divide-y divide-neutral-200 dark:divide-gray-700">
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg leading-6 font-medium text-neutral-900 dark:text-white">
                  Are the financial tools really free to use?
                </h3>
                <p className="mt-2 text-neutral-600 dark:text-gray-300">
                  Yes, all of our financial tools are completely free. We believe everyone should have access to quality financial resources without cost barriers.
                </p>
              </div>
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg leading-6 font-medium text-neutral-900 dark:text-white">
                  How is my data protected when I use the tools?
                </h3>
                <p className="mt-2 text-neutral-600 dark:text-gray-300">
                  Your privacy is important to us. We don't store any personal financial information you enter into our calculators or tools. All calculations happen in your browser.
                </p>
              </div>
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg leading-6 font-medium text-neutral-900 dark:text-white">
                  Do you offer personalized financial advice?
                </h3>
                <p className="mt-2 text-neutral-600 dark:text-gray-300">
                  Our platform provides educational resources and tools, not personalized financial advice. For advice specific to your situation, we recommend consulting with a qualified financial advisor.
                </p>
              </div>
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg leading-6 font-medium text-neutral-900 dark:text-white">
                  How often is your educational content updated?
                </h3>
                <p className="mt-2 text-neutral-600 dark:text-gray-300">
                  We regularly review and update our educational content to ensure it remains accurate and relevant. Our team stays informed on financial trends and best practices.
                </p>
              </div>
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg leading-6 font-medium text-neutral-900 dark:text-white">
                  Can I suggest topics for future articles or tools?
                </h3>
                <p className="mt-2 text-neutral-600 dark:text-gray-300">
                  Absolutely! We welcome suggestions from our community. You can send your ideas through our contact form or by emailing us at suggestions@finsmart.com.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Budget Calculator Section */}
      <section id="budget-calculator" className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-base font-semibold text-primary dark:text-primary-400 uppercase tracking-wide">Financial Tools</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 dark:text-white sm:text-4xl">
              50/30/20 Budget Calculator
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 dark:text-gray-300 mx-auto">
              Plan your budget efficiently using the popular 50/30/20 rule for financial stability.
            </p>
          </div>
          <BudgetCalculator />
        </div>
      </section>

      {/* Newsletter Signup */}
      <NewsletterSignup />
    </div>
  );
};

export default Resources;
