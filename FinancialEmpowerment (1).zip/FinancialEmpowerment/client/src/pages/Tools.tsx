import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BudgetCalculator from "@/components/BudgetCalculator";
import SavingsGoalTracker from "@/components/SavingsGoalTracker";
import CurrencyInvestment from "@/components/CurrencyInvestment";
import { AnalyticsUpdater } from "@/components/analytics/AnalyticsUpdater";
import { DataReconciliation } from "@/components/analytics/DataReconciliation";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

const Tools = () => {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  
  // State for savings transfer between budget calculator and investment tool
  const [transferAmount, setTransferAmount] = useState<number | undefined>(undefined);
  const [transferCurrency, setTransferCurrency] = useState<string | undefined>(undefined);
  
  // Get the hash from URL to set initial tab
  const [activeTab, setActiveTab] = useState(() => {
    const hash = window.location.hash;
    if (hash === "#savings-goal-tracker") return "savings";
    if (hash === "#currency-investment") return "investment";
    return "budget"; // Default to budget calculator
  });

  // Handle redirect for financial health quiz
  useEffect(() => {
    // If someone tries to access the quiz directly via URL hash, redirect them to homepage
    if (window.location.hash === "#financial-health-quiz") {
      toast({
        title: "Quiz Moved",
        description: "The Financial Health Quiz is now available on the homepage",
      });
      
      setTimeout(() => {
        setLocation('/');
      }, 1500);
    }
  }, [setLocation, toast]);

  // Update URL hash when tab changes
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    
    // Update URL hash
    let hash = "#budget-calculator";
    if (value === "savings") hash = "#savings-goal-tracker";
    if (value === "investment") hash = "#currency-investment";
    
    window.history.replaceState(null, "", hash);
  };
  
  // Handler for when user wants to invest savings from the budget calculator
  const handleInvestSavings = (amount: number, currency: string) => {
    setTransferAmount(amount);
    setTransferCurrency(currency);
    
    // Switch to investment tab
    handleTabChange("investment");
    
    toast({
      title: "Switching to Investment Tool",
      description: `Transferring ${currency} ${amount.toLocaleString()} to Currency Investment tool`,
    });
  };

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-neutral-50 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-extrabold text-neutral-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
              Financial Tools
            </h1>
            <p className="mt-5 text-xl text-neutral-500">
              Interactive tools to help you build financial wellness and achieve your money goals.
            </p>
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-base font-semibold text-primary uppercase tracking-wide">Interactive Tools</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 sm:text-4xl">
              Financial Tools That Empower You
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 mx-auto">
              Use our simple, interactive tools to improve your financial well-being.
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger id="budget-calculator" value="budget" className="text-base py-3">Budget Calculator</TabsTrigger>
              <TabsTrigger id="savings-goal-tracker" value="savings" className="text-base py-3">Savings Goal Tracker</TabsTrigger>
              <TabsTrigger id="currency-investment" value="investment" className="text-base py-3">Currency Investment</TabsTrigger>
            </TabsList>
            
            <TabsContent value="budget" className="mt-2">
              <BudgetCalculator onInvestSavings={handleInvestSavings} />
            </TabsContent>
            
            <TabsContent value="savings" className="mt-2">
              <SavingsGoalTracker />
            </TabsContent>
            
            <TabsContent value="investment" className="mt-2">
              <CurrencyInvestment 
                initialAmount={transferAmount} 
                initialCurrency={transferCurrency} 
              />
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Analytics Tools Section */}
      <section className="py-16 bg-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-base font-semibold text-primary uppercase tracking-wide">Analytics Tools</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 sm:text-4xl">
              Update Your Financial Analytics
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 mx-auto">
              Keep your financial dashboards up-to-date with the latest data.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <AnalyticsUpdater 
              userId={String(user?.id)}
              onUpdateComplete={() => {
                toast({
                  title: "Analytics Updated",
                  description: "Your analytics dashboards have been refreshed with the latest data.",
                });
              }}
            />
            
            <DataReconciliation 
              onReconcileComplete={() => {
                toast({
                  title: "Data Reconciled",
                  description: "Your financial data has been successfully reconciled.",
                });
              }}
            />
          </div>
        </div>
      </section>

      {/* Why Use Our Tools */}
      <section className="py-16 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center">
            <h2 className="text-base font-semibold text-primary uppercase tracking-wide">Benefits</h2>
            <p className="mt-2 text-3xl font-extrabold text-neutral-900 sm:text-4xl">
              Why Use Our Financial Tools
            </p>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 lg:mx-auto">
              Our tools are designed to make financial management accessible and actionable for everyone.
            </p>
          </div>

          <div className="mt-12">
            <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10">
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-neutral-900">Private & Secure</h3>
                  <p className="mt-2 text-base text-neutral-500">
                    Your financial data stays private. We don't store or share your sensitive information.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-neutral-900">Free to Use</h3>
                  <p className="mt-2 text-base text-neutral-500">
                    All our tools are completely free. No hidden fees, no subscriptions required.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-neutral-900">Instant Results</h3>
                  <p className="mt-2 text-base text-neutral-500">
                    Get immediate insights and calculations to help you make better financial decisions.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-neutral-900">Customizable</h3>
                  <p className="mt-2 text-base text-neutral-500">
                    Adjust the tools to match your specific financial situation and goals.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Tools;
