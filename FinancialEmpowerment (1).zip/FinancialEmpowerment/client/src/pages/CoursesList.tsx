import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  Clock, 
  Book, 
  ArrowRight, 
  GraduationCap, 
  Search, 
  User, 
  Star, 
  Users 
} from "lucide-react";
import type { CourseData } from "@/lib/types";

const CoursesList = () => {
  const [, setLocation] = useLocation();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeLevel, setActiveLevel] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<string>("featured");

  const coursesQuery = useQuery({
    queryKey: ["/api/courses", activeCategory, activeLevel],
    queryFn: async () => {
      let url = "/api/courses";
      const params = new URLSearchParams();
      
      if (activeCategory) {
        params.append("category", activeCategory);
      }
      
      if (activeLevel) {
        params.append("level", activeLevel);
      }
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Failed to fetch courses");
      }
      return response.json() as Promise<CourseData[]>;
    }
  });

  // Filter courses based on search query
  const filteredCourses = coursesQuery.data?.filter(course => {
    if (!searchQuery) return true;
    return (
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (course.instructor && course.instructor.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (course.tags && course.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())))
    );
  });

  // Get featured courses
  const featuredCourses = coursesQuery.data?.filter(course => course.featured) || [];

  // Sort courses based on selected criteria
  const sortedCourses = [...(filteredCourses || [])].sort((a, b) => {
    switch (sortBy) {
      case "popular":
        return (b.popularity || 0) - (a.popularity || 0);
      case "rating":
        return (b.averageRating || 0) - (a.averageRating || 0);
      case "newest":
        return new Date(b.createdAt || Date.now()).getTime() - new Date(a.createdAt || Date.now()).getTime();
      case "enrollment":
        return (b.enrollmentCount || 0) - (a.enrollmentCount || 0);
      case "featured":
      default:
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    }
  });

  const handleCategoryChange = (category: string | null) => {
    setActiveCategory(category);
  };

  const handleLevelChange = (level: string) => {
    setActiveLevel(level === "all" ? null : level);
  };

  const handleSortChange = (value: string) => {
    setSortBy(value);
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Beginner":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300";
      case "Intermediate":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300";
      case "Advanced":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  // Reset search when filters change
  useEffect(() => {
    setSearchQuery("");
  }, [activeCategory, activeLevel]);

  return (
    <div className="container mx-auto py-8 px-4 md:px-6">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-blue-500 to-teal-400 text-transparent bg-clip-text dark:from-blue-400 dark:to-teal-300">
          Financial Education Courses
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Build your financial knowledge with our structured learning paths. From basics to advanced topics, our courses are designed to help you gain confidence in personal finance.
        </p>
      </div>

      {/* Featured Courses Section */}
      {featuredCourses.length > 0 && (
        <div className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Recommended Courses</h2>
            <Link href="/courses/list">
              <Button variant="ghost" className="text-primary">
                View all <ArrowRight size={16} className="ml-2" />
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredCourses.slice(0, 3).map((course) => (
              <Card 
                key={course.id} 
                className="overflow-hidden h-full flex flex-col transition-shadow hover:shadow-lg dark:border-gray-700"
              >
                <div className="relative h-48 bg-blue-50 dark:bg-blue-950">
                  {(course.thumbnailUrl || course.imageUrl) ? (
                    <img 
                      src={course.thumbnailUrl || course.imageUrl} 
                      alt={course.title} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <GraduationCap size={64} className="text-blue-300" />
                    </div>
                  )}
                  <Badge className={`absolute top-4 right-4 ${getLevelColor(course.level)}`}>
                    {course.level}
                  </Badge>
                  {course.featured && (
                    <Badge className="absolute top-4 left-4 bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300">
                      Featured
                    </Badge>
                  )}
                </div>
                <CardHeader className="py-4">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg font-bold">{course.title}</CardTitle>
                  </div>
                  <div className="flex items-center mt-1 space-x-2">
                    <Badge variant="outline" className="text-xs">{course.category}</Badge>
                    {course.tags && course.tags.slice(0, 2).map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">{tag}</Badge>
                    ))}
                  </div>
                  <CardDescription className="line-clamp-2 mt-2">
                    {course.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow py-2">
                  {course.instructor && (
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-2">
                      <User size={16} className="mr-2" />
                      <span>{course.instructor}</span>
                    </div>
                  )}
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-2">
                    <Clock size={16} className="mr-2" />
                    <span>{course.durationMinutes} minutes</span>
                  </div>
                  {course.averageRating && (
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-2">
                      <Star size={16} className="mr-2 text-yellow-500" />
                      <span>{course.averageRating.toFixed(1)}</span>
                    </div>
                  )}
                  {course.enrollmentCount !== undefined && course.enrollmentCount > 0 && (
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                      <Users size={16} className="mr-2" />
                      <span>{course.enrollmentCount} students</span>
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    onClick={() => setLocation(`/courses/${course.id}`)}
                  >
                    View Course <ArrowRight size={16} className="ml-2" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Filter and Search Section */}
      <div className="mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div>
              <label htmlFor="search" className="block text-sm font-medium mb-2 text-gray-900 dark:text-gray-100">
                Search Courses
              </label>
              <div className="relative">
                <Input
                  id="search"
                  placeholder="Search by title, description or instructor..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
                <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>

            <div>
              <label htmlFor="level-filter" className="block text-sm font-medium mb-2 text-gray-900 dark:text-gray-100">
                Difficulty Level
              </label>
              <Select 
                defaultValue="all"
                onValueChange={handleLevelChange}
              >
                <SelectTrigger id="level-filter">
                  <SelectValue placeholder="All Levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="Beginner">Beginner</SelectItem>
                  <SelectItem value="Intermediate">Intermediate</SelectItem>
                  <SelectItem value="Advanced">Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label htmlFor="sort-by" className="block text-sm font-medium mb-2 text-gray-900 dark:text-gray-100">
                Sort By
              </label>
              <Select value={sortBy} onValueChange={handleSortChange}>
                <SelectTrigger id="sort-by">
                  <SelectValue placeholder="Featured" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="popular">Most Popular</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="enrollment">Most Enrolled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <div className="mb-6">
              <h2 className="text-lg font-medium mb-2 text-gray-900 dark:text-gray-100">Categories</h2>
              <TabsList className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                <TabsTrigger 
                  value="all" 
                  onClick={() => handleCategoryChange(null)}
                >
                  All Categories
                </TabsTrigger>
                <TabsTrigger 
                  value="budgeting" 
                  onClick={() => handleCategoryChange("Budgeting")}
                >
                  Budgeting
                </TabsTrigger>
                <TabsTrigger 
                  value="investing" 
                  onClick={() => handleCategoryChange("Investing")}
                >
                  Investing
                </TabsTrigger>
                <TabsTrigger 
                  value="saving" 
                  onClick={() => handleCategoryChange("Saving")}
                >
                  Saving
                </TabsTrigger>
                <TabsTrigger 
                  value="retirement" 
                  onClick={() => handleCategoryChange("Retirement")}
                >
                  Retirement
                </TabsTrigger>
              </TabsList>
            </div>
          </Tabs>
        </div>
      </div>

      {/* Courses Grid */}
      <div className="mb-8">
        {coursesQuery.isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <CardHeader>
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3 mt-2" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-1/2 mb-2" />
                  <Skeleton className="h-4 w-2/3 mb-2" />
                </CardContent>
                <CardFooter>
                  <Skeleton className="h-10 w-full" />
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : coursesQuery.isError ? (
          <div className="text-center py-8">
            <p className="text-red-500 mb-4">Failed to load courses. Please try again.</p>
            <Button onClick={() => coursesQuery.refetch()}>Retry</Button>
          </div>
        ) : sortedCourses && sortedCourses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedCourses.map((course) => (
              <Card 
                key={course.id} 
                className="overflow-hidden h-full flex flex-col transition-shadow hover:shadow-lg dark:border-gray-700"
              >
                <div className="relative h-48 bg-blue-50 dark:bg-blue-950">
                  {(course.thumbnailUrl || course.imageUrl) ? (
                    <img 
                      src={course.thumbnailUrl || course.imageUrl} 
                      alt={course.title} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <GraduationCap size={64} className="text-blue-300" />
                    </div>
                  )}
                  <Badge className={`absolute top-4 right-4 ${getLevelColor(course.level)}`}>
                    {course.level}
                  </Badge>
                  {course.featured && (
                    <Badge className="absolute top-4 left-4 bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300">
                      Featured
                    </Badge>
                  )}
                </div>
                <CardHeader className="py-4">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg font-bold">{course.title}</CardTitle>
                  </div>
                  <div className="flex items-center mt-1 space-x-2 flex-wrap">
                    <Badge variant="outline" className="text-xs mb-1">{course.category}</Badge>
                    {course.tags && course.tags.slice(0, 2).map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs mb-1">{tag}</Badge>
                    ))}
                  </div>
                  <CardDescription className="line-clamp-2 mt-2">
                    {course.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow py-2">
                  {course.instructor && (
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-2">
                      <User size={16} className="mr-2" />
                      <span>{course.instructor}</span>
                    </div>
                  )}
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-2">
                    <Clock size={16} className="mr-2" />
                    <span>{course.durationMinutes} minutes</span>
                  </div>
                  {course.averageRating && (
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-2">
                      <Star size={16} className="mr-2 text-yellow-500" />
                      <span>{course.averageRating.toFixed(1)}</span>
                    </div>
                  )}
                  {course.enrollmentCount !== undefined && course.enrollmentCount > 0 && (
                    <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                      <Users size={16} className="mr-2" />
                      <span>{course.enrollmentCount} students</span>
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    onClick={() => setLocation(`/courses/${course.id}`)}
                  >
                    View Course <ArrowRight size={16} className="ml-2" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-10 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
            <GraduationCap size={64} className="mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-medium text-gray-700 dark:text-gray-200 mb-2">No courses found</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-6">
              {searchQuery ? 
                `No courses match "${searchQuery}". Try a different search term.` :
                (activeCategory || activeLevel) ? 
                  "Try changing your filters to see more courses." : 
                  "We're working on adding courses. Check back soon!"}
            </p>
            {(activeCategory || activeLevel || searchQuery) && (
              <Button 
                variant="outline" 
                onClick={() => {
                  setActiveCategory(null);
                  setActiveLevel(null);
                  setSearchQuery("");
                }}
              >
                Clear Filters
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default CoursesList;