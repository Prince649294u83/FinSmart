import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { BarChart4, AlertTriangle, Target, PlusCircle, Download, Share2, Settings, Laptop2 } from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import { AnalyticsDashboard } from '@/components/analytics/AnalyticsCharts';
import { AnomalyAlerts } from '@/components/analytics/AnomalyAlerts';
import { GoalTracking } from '@/components/analytics/GoalTracking';
import { AnalyticsUpdater } from '@/components/analytics/AnalyticsUpdater';
import { DataReconciliation } from '@/components/analytics/DataReconciliation';

// Example data for charts (real data will come from API)
const getDefaultData = (userId: number) => {
  return {
    spendingByCategory: [
      { name: 'Housing', value: 1200 },
      { name: 'Food', value: 450 },
      { name: 'Transportation', value: 300 },
      { name: 'Entertainment', value: 150 },
      { name: 'Utilities', value: 200 },
      { name: 'Healthcare', value: 100 },
    ],
    monthlySpending: [
      { name: 'Jan', amount: 2300 },
      { name: 'Feb', amount: 2100 },
      { name: 'Mar', amount: 2400 },
      { name: 'Apr', amount: 2200 },
      { name: 'May', amount: 2800 },
      { name: 'Jun', amount: 2600 },
    ],
    investmentPerformance: [
      { name: 'Jan', value: 10000 },
      { name: 'Feb', value: 10200 },
      { name: 'Mar', value: 10150 },
      { name: 'Apr', value: 10400 },
      { name: 'May', value: 10550 },
      { name: 'Jun', value: 10700 },
    ],
    goalProgress: [
      { name: 'Emergency Fund', current: 3000, remaining: 2000 },
      { name: 'Vacation', current: 1500, remaining: 500 },
      { name: 'Down Payment', current: 15000, remaining: 35000 },
    ]
  };
};

export default function AnalyticsPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");
  
  // Fetch analytics reports
  const { data: reports = [], isLoading: isLoadingReports } = useQuery({
    queryKey: ['/api/analytics/reports', { userId: user?.id }],
    queryFn: async ({ queryKey }) => {
      const [_, { userId }] = queryKey as [string, { userId: number }];
      try {
        const res = await fetch(`/api/analytics/reports?userId=${userId}`);
        if (!res.ok) throw new Error('Failed to fetch reports');
        return res.json();
      } catch (error) {
        console.error('Error fetching reports:', error);
        return [];
      }
    },
    enabled: !!user?.id,
  });
  
  // Fetch unread alert count
  const { data: alerts = [], isLoading: isLoadingAlerts } = useQuery({
    queryKey: ['/api/analytics/alerts', { userId: user?.id, unreadOnly: true }],
    queryFn: async ({ queryKey }) => {
      const [_, { userId }] = queryKey as [string, { userId: number, unreadOnly: boolean }];
      try {
        const res = await fetch(`/api/analytics/alerts?userId=${userId}&unreadOnly=true`);
        if (!res.ok) throw new Error('Failed to fetch alerts');
        return res.json();
      } catch (error) {
        console.error('Error fetching alerts:', error);
        return [];
      }
    },
    enabled: !!user?.id,
  });
  
  // Get chart data, either from reports or fallback to defaults
  const getChartData = () => {
    // If we have saved reports, use that data
    if (reports.length > 0) {
      // Find the most recent reports by type
      const spendingReport = reports.find((r: any) => r.type === 'spending');
      const investmentReport = reports.find((r: any) => r.type === 'investment');
      const goalReport = reports.find((r: any) => r.type === 'goal');
      
      return {
        spendingByCategory: spendingReport?.data?.categoryData || getDefaultData(user?.id || 0).spendingByCategory,
        monthlySpending: spendingReport?.data?.monthlyData || getDefaultData(user?.id || 0).monthlySpending,
        investmentPerformance: investmentReport?.data?.performanceData || getDefaultData(user?.id || 0).investmentPerformance,
        goalProgress: goalReport?.data?.progressData || getDefaultData(user?.id || 0).goalProgress,
      };
    }
    
    // Fallback to default data
    return getDefaultData(user?.id || 0);
  };
  
  const chartData = getChartData();
  const unreadAlertsCount = alerts.length;
  
  return (
    <div className="container mx-auto py-6 max-w-7xl">
      <div className="flex flex-col gap-2 md:flex-row md:justify-between md:items-center pb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Financial Analytics</h1>
          <p className="text-muted-foreground">
            Track your financial health with custom reports and insights
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="hidden md:flex">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button variant="outline" size="sm" className="hidden md:flex">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
          <Button size="sm">
            <PlusCircle className="h-4 w-4 mr-2" />
            New Report
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Reports</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <BarChart4 className="h-5 w-5 text-muted-foreground mr-2" />
              <div className="text-2xl font-bold">{reports.length}</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className={unreadAlertsCount > 0 ? "border-orange-500" : ""}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              Unread Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <AlertTriangle className={`h-5 w-5 mr-2 ${unreadAlertsCount > 0 ? "text-orange-500" : "text-muted-foreground"}`} />
              <div className="text-2xl font-bold">{unreadAlertsCount}</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Goals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Target className="h-5 w-5 text-muted-foreground mr-2" />
              <div className="text-2xl font-bold">{chartData.goalProgress.length}</div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard">Analytics Dashboard</TabsTrigger>
          <TabsTrigger value="alerts" className="relative">
            Anomaly Detection
            {unreadAlertsCount > 0 && (
              <span className="absolute top-1 right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-orange-500"></span>
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="goals">Goal Tracking</TabsTrigger>
          <TabsTrigger value="data-management">
            <Laptop2 className="h-4 w-4 mr-2" />
            Data Management
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="dashboard" className="space-y-4 mt-4">
          <AnalyticsDashboard
            spendingCategoryData={chartData.spendingByCategory}
            monthlySpendingData={chartData.monthlySpending}
            investmentData={chartData.investmentPerformance}
            goalData={chartData.goalProgress}
          />
        </TabsContent>
        
        <TabsContent value="alerts" className="mt-4">
          <AnomalyAlerts />
        </TabsContent>
        
        <TabsContent value="goals" className="mt-4">
          <GoalTracking />
        </TabsContent>
        
        <TabsContent value="data-management" className="mt-4">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold">Financial Data Management</h2>
              <p className="text-muted-foreground">Update and reconcile your financial data from multiple sources</p>
            </div>
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4 mr-2" />
              Data Source Settings
            </Button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <AnalyticsUpdater 
              userId={String(user?.id)}
              onUpdateComplete={() => {
                setActiveTab("dashboard");
              }}
            />
            <DataReconciliation 
              onReconcileComplete={() => {
                setActiveTab("dashboard");
              }}
            />
          </div>
        </TabsContent>
      </Tabs>
      
      <div className="mt-8">
        <Separator className="my-4" />
        <div className="text-sm text-muted-foreground">
          <p>Analytics data is updated daily. Reports and alerts are generated based on your financial activity.</p>
          <p className="mt-1">For more detailed analysis, use the "New Report" button to create custom reports.</p>
        </div>
      </div>
    </div>
  );
}