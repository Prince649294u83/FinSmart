import LearningResources from "@/components/LearningResources";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const Learn = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-neutral-50 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-extrabold text-neutral-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
              Financial Education
            </h1>
            <p className="mt-5 text-xl text-neutral-500">
              Build your financial knowledge and confidence with our collection of easy-to-understand resources.
            </p>
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="courses" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-neutral-900">Structured Learning Paths</h2>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 mx-auto">
              Take your financial education to the next level with our comprehensive courses.
            </p>
          </div>
          
          <div className="bg-gradient-to-r from-blue-500 to-teal-400 rounded-xl overflow-hidden shadow-xl">
            <div className="md:flex">
              <div className="md:w-1/2 p-8 md:p-12 text-white">
                <h3 className="text-2xl md:text-3xl font-bold mb-4">Financial Education Courses</h3>
                <p className="mb-6 text-white text-opacity-90">
                  Our structured courses guide you through key financial concepts step-by-step, from basics to advanced strategies.
                </p>
                <ul className="mb-8 space-y-2">
                  <li className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    Self-paced learning modules
                  </li>
                  <li className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    Interactive knowledge checks
                  </li>
                  <li className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    Practical exercises to apply concepts
                  </li>
                </ul>
                <Link href="/courses/list">
                  <Button className="bg-white text-primary hover:bg-neutral-50">
                    Browse All Courses
                  </Button>
                </Link>
              </div>
              <div className="md:w-1/2 bg-white p-8 md:p-12 flex items-center justify-center">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="text-blue-500 text-xl font-bold mb-2">Budgeting</div>
                    <p className="text-sm text-gray-600">Master the fundamentals of creating and maintaining a budget</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="text-green-500 text-xl font-bold mb-2">Investing</div>
                    <p className="text-sm text-gray-600">Learn investment strategies for long-term wealth building</p>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <div className="text-purple-500 text-xl font-bold mb-2">Debt</div>
                    <p className="text-sm text-gray-600">Strategies to manage and eliminate debt effectively</p>
                  </div>
                  <div className="bg-amber-50 p-4 rounded-lg">
                    <div className="text-amber-500 text-xl font-bold mb-2">Saving</div>
                    <p className="text-sm text-gray-600">Techniques to build emergency funds and save for goals</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section id="learning-resources" className="py-16 bg-neutral-50">
        <LearningResources showViewAll={false} />
      </section>

      {/* Categories Section */}
      <section id="categories" className="bg-neutral-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-neutral-900">Financial Topics</h2>
            <p className="mt-4 max-w-2xl text-xl text-neutral-500 mx-auto">
              Browse by category to find exactly what you need.
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            <a href="https://www.nerdwallet.com/article/finance/how-to-budget" target="_blank" rel="noopener noreferrer" className="group">
              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 group-hover:-translate-y-1">
                <div className="inline-flex items-center justify-center p-2 bg-blue-100 rounded-md text-blue-700 mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-neutral-900 mb-2">Budgeting Basics</h3>
                <p className="text-neutral-500">Learn to create and maintain a budget that works for you.</p>
                <p className="text-xs text-primary mt-2">Source: NerdWallet</p>
              </div>
            </a>

            <a href="https://www.investopedia.com/ask/answers/022916/what-502030-budget-rule.asp" target="_blank" rel="noopener noreferrer" className="group">
              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 group-hover:-translate-y-1">
                <div className="inline-flex items-center justify-center p-2 bg-green-100 rounded-md text-green-700 mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-neutral-900 mb-2">Saving Strategies</h3>
                <p className="text-neutral-500">Effective methods to save more, even on a tight budget.</p>
                <p className="text-xs text-primary mt-2">Source: Investopedia</p>
              </div>
            </a>

            <a href="https://www.fool.com/investing/how-to-invest/" target="_blank" rel="noopener noreferrer" className="group">
              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 group-hover:-translate-y-1">
                <div className="inline-flex items-center justify-center p-2 bg-indigo-100 rounded-md text-indigo-700 mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-neutral-900 mb-2">Investing 101</h3>
                <p className="text-neutral-500">Simple guides to start building wealth through investing.</p>
                <p className="text-xs text-primary mt-2">Source: The Motley Fool</p>
              </div>
            </a>

            <a href="https://www.ramseysolutions.com/debt/how-to-pay-off-debt" target="_blank" rel="noopener noreferrer" className="group">
              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 group-hover:-translate-y-1">
                <div className="inline-flex items-center justify-center p-2 bg-red-100 rounded-md text-red-700 mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-neutral-900 mb-2">Debt Management</h3>
                <p className="text-neutral-500">Strategies to tackle and eliminate debt effectively.</p>
                <p className="text-xs text-primary mt-2">Source: Ramsey Solutions</p>
              </div>
            </a>
          </div>
        </div>
      </section>

      {/* Call to action */}
      <section className="bg-primary py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Ready to put your knowledge into action?
          </h2>
          <p className="mt-4 text-lg leading-6 text-indigo-100">
            Try our interactive financial tools to apply what you've learned.
          </p>
          <div className="mt-8">
            <Link href="/tools">
              <Button className="bg-white text-primary hover:bg-neutral-50">
                Explore Financial Tools
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Learn;
