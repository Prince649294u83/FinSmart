import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Clock, Book, ArrowRight, GraduationCap } from "lucide-react";
import type { CourseData } from "@/lib/types";

export default function Courses() {
  const [, setLocation] = useLocation();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeLevel, setActiveLevel] = useState<string | null>(null);

  const coursesQuery = useQuery({
    queryKey: ["/api/courses", activeCategory, activeLevel],
    queryFn: async () => {
      let url = "/api/courses";
      const params = new URLSearchParams();
      
      if (activeCategory) {
        params.append("category", activeCategory);
      }
      
      if (activeLevel) {
        params.append("level", activeLevel);
      }
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Failed to fetch courses");
      }
      return response.json() as Promise<CourseData[]>;
    }
  });

  const handleCategoryChange = (category: string | null) => {
    setActiveCategory(category);
  };

  const handleLevelChange = (level: string | null) => {
    setActiveLevel(level);
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Beginner":
        return "bg-green-100 text-green-800";
      case "Intermediate":
        return "bg-blue-100 text-blue-800";
      case "Advanced":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="container mx-auto py-8 px-4 md:px-6">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-blue-500 to-teal-400 text-transparent bg-clip-text">
          Financial Education Courses
        </h1>
        <p className="text-lg text-gray-600">
          Build your financial knowledge with our structured learning paths. From basics to advanced topics, our courses are designed to help you gain confidence in personal finance.
        </p>
      </div>

      <div className="mb-8">
        <Tabs defaultValue="all" className="w-full">
          <div className="mb-6">
            <h2 className="text-lg font-medium mb-2">Filter by Category</h2>
            <TabsList className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <TabsTrigger 
                value="all" 
                onClick={() => handleCategoryChange(null)}
                className="data-[state=active]:bg-blue-500"
              >
                All Categories
              </TabsTrigger>
              <TabsTrigger 
                value="budgeting" 
                onClick={() => handleCategoryChange("Budgeting")}
                className="data-[state=active]:bg-blue-500"
              >
                Budgeting
              </TabsTrigger>
              <TabsTrigger 
                value="investing" 
                onClick={() => handleCategoryChange("Investing")}
                className="data-[state=active]:bg-blue-500"
              >
                Investing
              </TabsTrigger>
              <TabsTrigger 
                value="saving" 
                onClick={() => handleCategoryChange("Saving")}
                className="data-[state=active]:bg-blue-500"
              >
                Saving
              </TabsTrigger>
            </TabsList>
          </div>
          
          <div className="mb-6">
            <h2 className="text-lg font-medium mb-2">Filter by Level</h2>
            <TabsList className="grid grid-cols-3 gap-2">
              <TabsTrigger 
                value="all-levels" 
                onClick={() => handleLevelChange(null)}
                className="data-[state=active]:bg-blue-500"
              >
                All Levels
              </TabsTrigger>
              <TabsTrigger 
                value="beginner" 
                onClick={() => handleLevelChange("Beginner")}
                className="data-[state=active]:bg-blue-500"
              >
                Beginner
              </TabsTrigger>
              <TabsTrigger 
                value="intermediate" 
                onClick={() => handleLevelChange("Intermediate")}
                className="data-[state=active]:bg-blue-500"
              >
                Intermediate
              </TabsTrigger>
              <TabsTrigger 
                value="advanced" 
                onClick={() => handleLevelChange("Advanced")}
                className="data-[state=active]:bg-blue-500"
              >
                Advanced
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="all" className="mt-6">
            {coursesQuery.isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <Skeleton className="h-48 w-full" />
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-2/3 mt-2" />
                    </CardHeader>
                    <CardFooter>
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : coursesQuery.isError ? (
              <div className="text-center py-8">
                <p className="text-red-500 mb-4">Failed to load courses. Please try again.</p>
                <Button onClick={() => coursesQuery.refetch()}>Retry</Button>
              </div>
            ) : coursesQuery.data && coursesQuery.data.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {coursesQuery.data.map((course) => (
                  <Card key={course.id} className="overflow-hidden h-full flex flex-col">
                    <div className="relative h-48 bg-blue-50">
                      {course.imageUrl ? (
                        <img 
                          src={course.imageUrl} 
                          alt={course.title} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <GraduationCap size={64} className="text-blue-300" />
                        </div>
                      )}
                      <Badge className={`absolute top-4 right-4 ${getLevelColor(course.level)}`}>
                        {course.level}
                      </Badge>
                    </div>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg font-bold">{course.title}</CardTitle>
                        <Badge variant="outline" className="ml-2">{course.category}</Badge>
                      </div>
                      <CardDescription className="line-clamp-2 mt-2">
                        {course.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <div className="flex items-center text-sm text-gray-500 mb-2">
                        <Clock size={16} className="mr-2" />
                        <span>{course.durationMinutes} minutes</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Book size={16} className="mr-2" />
                        <span>{course.modules?.length || 0} modules</span>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        className="w-full" 
                        onClick={() => setLocation(`/courses/${course.id}`)}
                      >
                        View Course <ArrowRight size={16} className="ml-2" />
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <GraduationCap size={64} className="mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-medium text-gray-700 mb-2">No courses found</h3>
                <p className="text-gray-500 mb-6">
                  {activeCategory || activeLevel ? 
                    "Try changing your filters to see more courses." : 
                    "We're working on adding courses. Check back soon!"}
                </p>
                {(activeCategory || activeLevel) && (
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setActiveCategory(null);
                      setActiveLevel(null);
                    }}
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}