import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Link as LinkIcon, TrendingUp, DollarSign, BarChart2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface NewsItem {
  title: string;
  url: string;
  banner_image?: string;
  summary: string;
  time_published: string;
  source: string;
  category_within_source?: string;
  source_domain: string;
  topics?: Array<{topic: string; relevance_score: string}>;
}

interface FinancialNewsProps {
  limit?: number;
}

const FinancialNews = ({ limit = 6 }: FinancialNewsProps) => {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const { toast } = useToast();

  const { data: newsItems, isLoading, error } = useQuery({
    queryKey: ["/api/financial-news", activeCategory],
    queryFn: async () => {
      const response = await fetch(`/api/financial-news?category=${activeCategory}`);
      if (!response.ok) {
        throw new Error("Failed to fetch news");
      }
      const data = await response.json();
      return data as NewsItem[];
    },
  });

  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: "Failed to load financial news. Please try again later.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  const formatDate = (dateString: string) => {
    try {
      // Format: YYYYMMDDTHHMMSS - Example: 20230825T063559
      const year = dateString.substring(0, 4);
      const month = dateString.substring(4, 6);
      const day = dateString.substring(6, 8);
      const hour = dateString.substring(9, 11);
      const minute = dateString.substring(11, 13);
      const second = dateString.substring(13, 15);
      
      const date = new Date(`${year}-${month}-${day}T${hour}:${minute}:${second}`);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (error) {
      return "Unknown date";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch(category) {
      case "markets":
        return <TrendingUp className="h-5 w-5" />;
      case "economy":
        return <BarChart2 className="h-5 w-5" />;
      case "personal_finance":
        return <DollarSign className="h-5 w-5" />;
      default:
        return <Calendar className="h-5 w-5" />;
    }
  };

  const limitedNewsItems = newsItems ? newsItems.slice(0, limit) : [];

  return (
    <div className="w-full space-y-6">
      <div className="flex flex-col">
        <h2 className="text-2xl font-bold tracking-tight">Financial News</h2>
        <p className="text-muted-foreground">
          Stay updated with the latest financial news and market trends.
        </p>
      </div>

      <Tabs defaultValue="all" className="w-full" onValueChange={setActiveCategory}>
        <TabsList className="mb-4">
          <TabsTrigger value="all">All News</TabsTrigger>
          <TabsTrigger value="markets">Markets</TabsTrigger>
          <TabsTrigger value="economy">Economy</TabsTrigger>
          <TabsTrigger value="personal_finance">Personal Finance</TabsTrigger>
        </TabsList>

        <TabsContent value={activeCategory} className="mt-0">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(limit)].map((_, index) => (
                <Card key={index} className="overflow-hidden h-full flex flex-col">
                  <CardHeader className="p-0">
                    <Skeleton className="h-40 w-full rounded-t-lg" />
                  </CardHeader>
                  <CardContent className="flex-1 pt-6">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-2/3" />
                  </CardContent>
                  <CardFooter className="border-t pt-4">
                    <Skeleton className="h-4 w-1/3" />
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-10">
              <p className="text-destructive">Failed to load financial news.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => window.location.reload()}
              >
                Try Again
              </Button>
            </div>
          ) : limitedNewsItems.length === 0 ? (
            <div className="text-center py-10">
              <p>No news available for this category.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {limitedNewsItems.map((item, index) => (
                <Card key={index} className="overflow-hidden h-full flex flex-col">
                  {item.banner_image && (
                    <div className="h-40 overflow-hidden">
                      <img 
                        src={item.banner_image} 
                        alt={item.title} 
                        className="w-full h-full object-cover transition-transform hover:scale-105"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1000";
                        }}
                      />
                    </div>
                  )}
                  
                  <CardHeader className={!item.banner_image ? "pt-6" : ""}>
                    <CardTitle className="line-clamp-2 text-base">{item.title}</CardTitle>
                    <CardDescription className="flex items-center gap-1 text-xs">
                      {getCategoryIcon(item.category_within_source || "default")}
                      <span>{item.source}</span>
                      <span>•</span>
                      <span>{formatDate(item.time_published)}</span>
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent className="flex-1">
                    <p className="text-sm text-muted-foreground line-clamp-3">
                      {item.summary || "No summary available for this article."}
                    </p>
                  </CardContent>
                  
                  <CardFooter className="border-t pt-4">
                    <a 
                      href={item.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sm font-medium text-primary flex items-center gap-1 hover:underline"
                    >
                      <LinkIcon className="h-3 w-3" />
                      Read Full Article
                    </a>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FinancialNews;