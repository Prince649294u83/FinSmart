import React, { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormDescription } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { addMonths, format } from "date-fns";
import type { Currency, InvestmentOption, InvestmentSummary } from "@/lib/types";

// Available currencies for investment
const currencies: Currency[] = [
  { code: "USD", name: "US Dollar", symbol: "$" },
  { code: "EUR", name: "Euro", symbol: "€" },
  { code: "GBP", name: "British Pound", symbol: "£" },
  { code: "JPY", name: "Japanese Yen", symbol: "¥" },
  { code: "CNY", name: "Chinese Yuan", symbol: "¥" },
  { code: "CAD", name: "Canadian Dollar", symbol: "$" },
  { code: "AUD", name: "Australian Dollar", symbol: "$" },
  { code: "CHF", name: "Swiss Franc", symbol: "Fr" },
  { code: "HKD", name: "Hong Kong Dollar", symbol: "$" },
  { code: "SGD", name: "Singapore Dollar", symbol: "$" },
  { code: "INR", name: "Indian Rupee", symbol: "₹" },
  { code: "BRL", name: "Brazilian Real", symbol: "R$" },
  { code: "MXN", name: "Mexican Peso", symbol: "$" },
  { code: "RUB", name: "Russian Ruble", symbol: "₽" },
  { code: "KRW", name: "South Korean Won", symbol: "₩" },
];

// Investment options
const investmentOptions: InvestmentOption[] = [
  {
    id: "safe-deposit",
    name: "Safe Currency Deposit",
    description: "Low-risk investment with stable returns. Perfect for beginners.",
    minAmount: 500,
    maxAmount: 50000,
    term: "6 months",
    riskLevel: "Low",
    estimatedReturn: {
      min: 1.5,
      max: 2.5
    },
    currency: "USD"
  },
  {
    id: "currency-fund",
    name: "Currency Fund",
    description: "Medium-risk diversified currency portfolio managed by experts.",
    minAmount: 1000,
    maxAmount: 100000,
    term: "12 months",
    riskLevel: "Medium",
    estimatedReturn: {
      min: 3,
      max: 6
    },
    currency: "USD"
  },
  {
    id: "forex-trading",
    name: "Forex Trading Portfolio",
    description: "High-risk active trading in currency markets for maximum returns.",
    minAmount: 2000,
    maxAmount: 500000,
    term: "18 months",
    riskLevel: "High",
    estimatedReturn: {
      min: 5,
      max: 12
    },
    currency: "USD"
  }
];

// Validation schema
const investmentFormSchema = z.object({
  amount: z.coerce.number()
    .min(500, "Minimum investment amount is $500")
    .max(500000, "Maximum investment amount is $500,000"),
  currencyCode: z.string().min(1, "Please select a currency"),
  targetCurrency: z.string().min(1, "Please select a target currency"),
  optionId: z.string().min(1, "Please select an investment option"),
});

type InvestmentFormValues = z.infer<typeof investmentFormSchema>;

const defaultValues: InvestmentFormValues = {
  amount: 1000,
  currencyCode: "USD",
  targetCurrency: "EUR",
  optionId: "safe-deposit",
};

interface CurrencyInvestmentProps {
  initialAmount?: number;
  initialCurrency?: string;
}

const CurrencyInvestment = ({ initialAmount, initialCurrency }: CurrencyInvestmentProps) => {
  const { toast } = useToast();
  const [investmentSummary, setInvestmentSummary] = useState<InvestmentSummary | null>(null);
  
  // If initialAmount is provided from Budget Calculator, use it for the form
  const initialFormValues = {
    ...defaultValues,
    amount: initialAmount || defaultValues.amount,
    currencyCode: initialCurrency || defaultValues.currencyCode
  };
  
  // Get default values calculation for initial view
  const defaultOption = investmentOptions.find(opt => opt.id === initialFormValues.optionId);
  const defaultExchangeRate = 0.92; // USD to EUR exchange rate as default
  const defaultEstimatedReturn = defaultOption ? 
    (defaultOption.estimatedReturn.min + defaultOption.estimatedReturn.max) / 2 : 2.0;
  
  const [selectedOption, setSelectedOption] = useState<InvestmentOption | null>(defaultOption || null);

  const form = useForm<InvestmentFormValues>({
    resolver: zodResolver(investmentFormSchema),
    defaultValues: initialFormValues,
  });
  
  // Display notification if initialAmount was provided
  useEffect(() => {
    if (initialAmount && initialCurrency) {
      toast({
        title: "Savings transferred",
        description: `${initialCurrency} ${initialAmount.toLocaleString()} transferred from Budget Calculator`,
      });
      
      // Update form field values
      form.setValue("amount", initialAmount);
      form.setValue("currencyCode", initialCurrency);
    }
  }, [initialAmount, initialCurrency, form, toast]);

  const saveInvestment = useMutation({
    mutationFn: async (data: InvestmentFormValues) => {
      const option = investmentOptions.find(opt => opt.id === data.optionId);
      if (!option) throw new Error("Invalid investment option");

      // Calculate maturity date based on term
      const termMonths = parseInt(option.term.split(' ')[0]);
      const maturityDate = addMonths(new Date(), termMonths);
      
      // Calculate exchange rate (in a real app, this would come from an API)
      // Here we're using simplified dummy rates
      const exchangeRate = getExchangeRate(data.currencyCode, data.targetCurrency);
      
      // Calculate estimated return (average of min and max)
      const estimatedReturn = (option.estimatedReturn.min + option.estimatedReturn.max) / 2;
      
      // In a real app, we would use a real userId
      const payload = {
        userId: 1,
        currencyCode: data.currencyCode,
        amount: data.amount,
        exchangeRate,
        targetCurrency: data.targetCurrency,
        estimatedReturn,
        riskLevel: option.riskLevel,
        maturityDate,
      };
      
      const response = await apiRequest("POST", "/api/investments", payload);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/investments"] });
      toast({
        title: "Investment created",
        description: "Your investment has been saved successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create your investment. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Helper function to get exchange rate (simplified)
  const getExchangeRate = (fromCurrency: string, toCurrency: string): number => {
    // In a real app, this would call an external API
    // Simplified rates for demo purposes
    const rates: Record<string, Record<string, number>> = {
      "USD": { "EUR": 0.92, "GBP": 0.79, "JPY": 150.2, "CNY": 7.2, "USD": 1 },
      "EUR": { "USD": 1.09, "GBP": 0.86, "JPY": 163.5, "CNY": 7.83, "EUR": 1 },
      "GBP": { "USD": 1.27, "EUR": 1.16, "JPY": 190.12, "CNY": 9.11, "GBP": 1 },
      "JPY": { "USD": 0.0067, "EUR": 0.0061, "GBP": 0.0053, "CNY": 0.048, "JPY": 1 },
      "CNY": { "USD": 0.14, "EUR": 0.13, "GBP": 0.11, "JPY": 20.86, "CNY": 1 }
    };
    
    // Default rates for other currencies
    const defaultRates: Record<string, number> = { "USD": 1, "EUR": 0.92, "GBP": 0.79, "JPY": 150.2, "CNY": 7.2 };
    
    // If we have the specific rate, return it
    if (rates[fromCurrency] && rates[fromCurrency][toCurrency]) {
      return rates[fromCurrency][toCurrency];
    }
    
    // Otherwise return a default rate (1 for same currency)
    return fromCurrency === toCurrency ? 1 : (defaultRates[toCurrency] || 1);
  };

  const calculateInvestment = (data: InvestmentFormValues) => {
    const option = investmentOptions.find(opt => opt.id === data.optionId);
    if (!option) return;

    setSelectedOption(option);
    
    // Calculate maturity date based on term
    const termMonths = parseInt(option.term.split(' ')[0]);
    const maturityDate = addMonths(new Date(), termMonths);
    
    // Get exchange rate
    const exchangeRate = getExchangeRate(data.currencyCode, data.targetCurrency);
    
    // Calculate estimated return (average of min and max)
    const estimatedReturn = (option.estimatedReturn.min + option.estimatedReturn.max) / 2;
    
    setInvestmentSummary({
      amount: data.amount,
      currencyCode: data.currencyCode,
      targetCurrency: data.targetCurrency,
      exchangeRate,
      estimatedReturn,
      riskLevel: option.riskLevel,
      maturityDate,
    });

    // Optionally save the investment
    saveInvestment.mutate(data);
  };

  const handleOptionChange = (optionId: string) => {
    const option = investmentOptions.find(opt => opt.id === optionId);
    setSelectedOption(option || null);
  };

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden">
      <CardContent className="px-6 py-8">
        <h3 className="text-2xl font-bold text-neutral-900 mb-4">Currency Investment Options</h3>
        <p className="text-neutral-600 mb-6">
          Diversify your portfolio with international currency investments.
        </p>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(calculateInvestment)} className="space-y-6">
            {/* Investment Options */}
            <FormField
              control={form.control}
              name="optionId"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>Investment Strategy</FormLabel>
                  <FormDescription>
                    Choose an investment strategy that matches your risk tolerance.
                  </FormDescription>
                  <RadioGroup
                    onValueChange={(value) => {
                      field.onChange(value);
                      handleOptionChange(value);
                    }}
                    value={field.value}
                    className="space-y-4"
                  >
                    {investmentOptions.map((option) => (
                      <div key={option.id} className="flex items-start space-x-3 p-4 border rounded-lg transition-all hover:bg-neutral-50">
                        <RadioGroupItem value={option.id} id={option.id} className="mt-1" />
                        <div className="flex-1">
                          <label htmlFor={option.id} className="text-base font-medium text-neutral-900 flex items-center cursor-pointer">
                            {option.name}
                            <span className={`ml-2 text-xs font-semibold rounded-full px-2 py-0.5 ${
                              option.riskLevel === 'Low' ? 'bg-green-100 text-green-800' :
                              option.riskLevel === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {option.riskLevel} Risk
                            </span>
                          </label>
                          <p className="mt-1 text-sm text-neutral-500">{option.description}</p>
                          <div className="mt-2 text-sm text-neutral-600">
                            <span className="font-medium">Term:</span> {option.term} • 
                            <span className="font-medium ml-1">Return:</span> {option.estimatedReturn.min}% - {option.estimatedReturn.max}%
                          </div>
                        </div>
                      </div>
                    ))}
                  </RadioGroup>
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Investment Amount */}
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Investment Amount</FormLabel>
                    <FormDescription>
                      {selectedOption && (
                        <>Min: {selectedOption.currency}{selectedOption.minAmount.toLocaleString()} • 
                        Max: {selectedOption.currency}{selectedOption.maxAmount.toLocaleString()}</>
                      )}
                    </FormDescription>
                    <FormControl>
                      <div className="relative rounded-md shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <span className="text-neutral-500 sm:text-sm">$</span>
                        </div>
                        <Input
                          type="number"
                          className="pl-7 focus:ring-primary focus:border-primary block w-full sm:text-sm border-neutral-300 rounded-md"
                          placeholder="1000"
                          {...field}
                        />
                      </div>
                    </FormControl>
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                {/* From Currency */}
                <FormField
                  control={form.control}
                  name="currencyCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>From Currency</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {currencies.map((currency) => (
                            <SelectItem key={currency.code} value={currency.code}>
                              {currency.code} - {currency.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />

                {/* To Currency */}
                <FormField
                  control={form.control}
                  name="targetCurrency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>To Currency</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {currencies.map((currency) => (
                            <SelectItem key={currency.code} value={currency.code}>
                              {currency.code} - {currency.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="pt-4">
              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary-600"
                disabled={saveInvestment.isPending}
              >
                {saveInvestment.isPending ? "Processing..." : "Create Investment"}
              </Button>
            </div>
          </form>
        </Form>

        {(investmentSummary || defaultExchangeRate) && (
          <div className="mt-8 p-6 bg-neutral-50 rounded-lg transition-all duration-300">
            <h4 className="font-medium text-neutral-900 mb-4">Investment Summary</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="bg-white p-4 rounded border border-neutral-200">
                <p className="text-sm text-neutral-500">Investment Amount</p>
                <p className="text-xl font-semibold mt-1">
                  {investmentSummary?.currencyCode || defaultValues.currencyCode} {(investmentSummary?.amount || defaultValues.amount).toLocaleString()}
                </p>
              </div>
              
              <div className="bg-white p-4 rounded border border-neutral-200">
                <p className="text-sm text-neutral-500">Target Currency</p>
                <p className="text-xl font-semibold mt-1">
                  {investmentSummary?.targetCurrency || defaultValues.targetCurrency}
                </p>
                <p className="text-xs text-neutral-500 mt-1">
                  Exchange Rate: {investmentSummary?.exchangeRate.toFixed(4) || defaultExchangeRate.toFixed(4)}
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded border border-neutral-200">
                <p className="text-sm text-neutral-500">Estimated Value</p>
                <p className="text-xl font-semibold mt-1">
                  {investmentSummary?.targetCurrency || defaultValues.targetCurrency} {(
                    (investmentSummary?.amount || defaultValues.amount) * 
                    (investmentSummary?.exchangeRate || defaultExchangeRate)
                  ).toLocaleString(undefined, {maximumFractionDigits: 2})}
                </p>
              </div>
              
              <div className="bg-white p-4 rounded border border-neutral-200">
                <p className="text-sm text-neutral-500">Estimated Return</p>
                <p className="text-xl font-semibold text-green-600 mt-1">
                  {investmentSummary?.estimatedReturn || defaultEstimatedReturn}%
                </p>
              </div>
              
              <div className="bg-white p-4 rounded border border-neutral-200">
                <p className="text-sm text-neutral-500">Maturity Date</p>
                <p className="text-xl font-semibold mt-1">
                  {investmentSummary?.maturityDate
                    ? format(investmentSummary.maturityDate, 'MMM d, yyyy')
                    : format(addMonths(new Date(), 6), 'MMM d, yyyy')}
                </p>
              </div>
            </div>
            
            <div className="mt-6 bg-blue-50 p-4 rounded-lg border border-blue-100">
              <h5 className="font-medium text-blue-800 mb-2">Potential Earnings</h5>
              <p className="text-blue-700">
                Estimated final value: {investmentSummary?.targetCurrency || defaultValues.targetCurrency} {(
                  (investmentSummary?.amount || defaultValues.amount) * 
                  (investmentSummary?.exchangeRate || defaultExchangeRate) * 
                  (1 + (investmentSummary?.estimatedReturn || defaultEstimatedReturn) / 100)
                ).toLocaleString(undefined, {maximumFractionDigits: 2})}
              </p>
              <p className="text-sm text-blue-600 mt-1">
                Note: Actual returns may vary based on market conditions.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CurrencyInvestment;