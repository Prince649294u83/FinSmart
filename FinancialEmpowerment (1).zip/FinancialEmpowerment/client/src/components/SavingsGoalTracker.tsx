import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { differenceInMonths } from "date-fns";

const savingsGoalSchema = z.object({
  name: z.string().min(1, "Goal name is required"),
  targetAmount: z.coerce.number().min(1, "Target amount must be at least $1"),
  currentAmount: z.coerce.number().min(0, "Current savings must be at least $0"),
  targetDate: z.string().refine((date) => new Date(date) > new Date(), {
    message: "Target date must be in the future",
  }),
});

type SavingsGoalValues = z.infer<typeof savingsGoalSchema>;

const defaultValues: SavingsGoalValues = {
  name: "Emergency Fund",
  targetAmount: 5000,
  currentAmount: 1750,
  targetDate: new Date(new Date().getFullYear(), 11, 31).toISOString().split("T")[0], // End of current year
};

const SavingsGoalTracker = () => {
  const { toast } = useToast();
  const [goalSummary, setGoalSummary] = useState({
    name: defaultValues.name,
    percentComplete: Math.round((defaultValues.currentAmount / defaultValues.targetAmount) * 100),
    currentAmount: defaultValues.currentAmount,
    targetAmount: defaultValues.targetAmount,
    monthlySavingsNeeded: calculateMonthlySavings(
      defaultValues.targetAmount,
      defaultValues.currentAmount,
      defaultValues.targetDate
    ),
    targetDate: new Date(defaultValues.targetDate),
  });

  function calculateMonthlySavings(target: number, current: number, dateString: string): number {
    const targetDate = new Date(dateString);
    const today = new Date();
    const monthsRemaining = Math.max(1, differenceInMonths(targetDate, today) + 1);
    return Math.ceil((target - current) / monthsRemaining);
  }

  const form = useForm<SavingsGoalValues>({
    resolver: zodResolver(savingsGoalSchema),
    defaultValues,
  });

  const saveSavingsGoal = useMutation({
    mutationFn: async (data: SavingsGoalValues) => {
      // In a real app, we would use a real userId
      const payload = {
        userId: 1,
        name: data.name,
        targetAmount: data.targetAmount,
        currentAmount: data.currentAmount,
        targetDate: new Date(data.targetDate),
      };
      
      const response = await apiRequest("POST", "/api/savings-goals", payload);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/savings-goals"] });
      toast({
        title: "Savings goal saved",
        description: "Your savings goal has been saved successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save your savings goal. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateGoalTracker = (data: SavingsGoalValues) => {
    const { name, targetAmount, currentAmount, targetDate } = data;
    const percentComplete = Math.round((currentAmount / targetAmount) * 100);
    const monthlySavingsNeeded = calculateMonthlySavings(targetAmount, currentAmount, targetDate);

    setGoalSummary({
      name,
      percentComplete,
      currentAmount,
      targetAmount,
      monthlySavingsNeeded,
      targetDate: new Date(targetDate),
    });

    // Save goal to backend
    saveSavingsGoal.mutate(data);
  };

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden">
      <CardContent className="px-6 py-8">
        <h3 className="text-2xl font-bold text-neutral-900 mb-4">Savings Goal Tracker</h3>
        <p className="text-neutral-600 mb-6">
          Set a savings goal and track your progress towards achieving it.
        </p>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(updateGoalTracker)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-neutral-700">
                    Goal Name
                  </FormLabel>
                  <FormControl>
                    <Input 
                      className="mt-1 focus:ring-primary focus:border-primary block w-full shadow-sm sm:text-sm border-neutral-300 rounded-md" 
                      placeholder="Emergency Fund"
                      {...field} 
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="targetAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-neutral-700">
                      Target Amount
                    </FormLabel>
                    <FormControl>
                      <div className="relative rounded-md shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <span className="text-neutral-500 sm:text-sm">$</span>
                        </div>
                        <Input
                          type="number"
                          className="pl-7 focus:ring-primary focus:border-primary block w-full sm:text-sm border-neutral-300 rounded-md"
                          placeholder="0.00"
                          {...field}
                        />
                      </div>
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="currentAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-neutral-700">
                      Current Savings
                    </FormLabel>
                    <FormControl>
                      <div className="relative rounded-md shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <span className="text-neutral-500 sm:text-sm">$</span>
                        </div>
                        <Input
                          type="number"
                          className="pl-7 focus:ring-primary focus:border-primary block w-full sm:text-sm border-neutral-300 rounded-md"
                          placeholder="0.00"
                          {...field}
                        />
                      </div>
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="targetDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-neutral-700">
                    Target Date
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      className="mt-1 focus:ring-primary focus:border-primary block w-full shadow-sm sm:text-sm border-neutral-300 rounded-md"
                      {...field}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <div className="pt-4">
              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary-600"
                disabled={saveSavingsGoal.isPending}
              >
                {saveSavingsGoal.isPending ? "Updating..." : "Update Goal"}
              </Button>
            </div>
          </form>
        </Form>

        <div className="mt-6 p-4 bg-neutral-50 rounded-lg transition-all duration-300">
          <h4 className="font-medium text-neutral-900 mb-3">Goal Progress</h4>

          <div className="mb-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-medium text-neutral-700">{goalSummary.name}</span>
              <span className="text-sm font-medium text-green-600">
                {goalSummary.percentComplete}% Complete
              </span>
            </div>
            <Progress
              value={goalSummary.percentComplete}
              className="w-full h-2.5 bg-neutral-200"
              indicatorClassName="bg-green-500 transition-all duration-1000"
            />
          </div>

          <div className="grid grid-cols-2 gap-4 text-center text-sm mb-4">
            <div className="bg-white p-3 rounded border border-neutral-200">
              <p className="text-neutral-500">Current</p>
              <p className="text-2xl font-medium font-mono text-primary mt-1">
                ${goalSummary.currentAmount.toLocaleString()}
              </p>
            </div>
            <div className="bg-white p-3 rounded border border-neutral-200">
              <p className="text-neutral-500">Target</p>
              <p className="text-2xl font-medium font-mono text-neutral-800 mt-1">
                ${goalSummary.targetAmount.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="bg-white p-3 rounded border border-neutral-200 text-center">
            <p className="text-neutral-500 text-sm">Monthly savings needed</p>
            <p className="text-2xl font-medium font-mono text-indigo-600 mt-1">
              ${goalSummary.monthlySavingsNeeded.toLocaleString()}
            </p>
            <p className="text-xs text-neutral-500 mt-1">
              to reach your goal by {goalSummary.targetDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SavingsGoalTracker;
