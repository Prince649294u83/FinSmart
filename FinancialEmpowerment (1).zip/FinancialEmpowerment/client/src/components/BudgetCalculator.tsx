import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { CustomProgress } from "@/components/ui/custom-progress";
import { insertBudgetSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

// Create our own schema for the budget calculator frontend form
const budgetFormSchema = z.object({
  userId: z.number(),
  income: z.coerce.number().min(1, "Income must be at least 1"),
  housing: z.coerce.number().default(0),
  utilities: z.coerce.number().default(0),
  groceries: z.coerce.number().default(0),
  transportation: z.coerce.number().default(0),
  healthcare: z.coerce.number().default(0),
  debt: z.coerce.number().default(0),
  subscriptions: z.coerce.number().default(0),
  entertainment: z.coerce.number().default(0),
  dining: z.coerce.number().default(0),
  shopping: z.coerce.number().default(0),
  travel: z.coerce.number().default(0),
  miscellaneous: z.coerce.number().default(0),
  savings: z.coerce.number().default(0),
  investments: z.coerce.number().default(0),
  education: z.coerce.number().default(0)
});

type BudgetFormValues = z.infer<typeof budgetFormSchema>;

// Default values for the form
const defaultValues: BudgetFormValues = {
  userId: 0,
  income: 0,
  housing: 0,
  utilities: 0,
  groceries: 0,
  transportation: 0,
  healthcare: 0,
  subscriptions: 0,
  entertainment: 0,
  dining: 0,
  shopping: 0,
  travel: 0,
  education: 0,
  savings: 0,
  investments: 0,
  debt: 0,
  miscellaneous: 0
};

// Categories organized by the 50/30/20 rule
const needsCategories = ["housing", "utilities", "groceries", "transportation", "healthcare", "debt"];
const wantsCategories = ["subscriptions", "entertainment", "dining", "shopping", "travel", "miscellaneous"];
const savingsCategories = ["savings", "investments", "education"];

interface BudgetCalculatorProps {
  onInvestSavings?: (amount: number, currency: string) => void;
}

const BudgetCalculator = ({ onInvestSavings }: BudgetCalculatorProps) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [budgetResults, setBudgetResults] = useState<{
    needs: number;
    wants: number;
    savings: number;
    needsPercent: number;
    wantsPercent: number;
    savingsPercent: number;
    needsRecommended: number;
    wantsRecommended: number;
    savingsRecommended: number;
    needsDifference: number;
    wantsDifference: number;
    savingsDifference: number;
  } | null>(null);

  const form = useForm<BudgetFormValues>({
    resolver: zodResolver(budgetFormSchema),
    defaultValues: {
      ...defaultValues,
      userId: user?.id || 0
    },
  });

  const saveBudget = useMutation({
    mutationFn: async (data: BudgetFormValues) => {
      const response = await apiRequest("POST", "/api/budgets", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Budget saved",
        description: "Your budget has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save budget. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculateBudget = (data: BudgetFormValues) => {
    const income = data.income;
    
    // Calculate totals for each category
    const needs = needsCategories.reduce((sum, category) => sum + (data[category as keyof BudgetFormValues] as number || 0), 0);
    const wants = wantsCategories.reduce((sum, category) => sum + (data[category as keyof BudgetFormValues] as number || 0), 0);
    const savings = savingsCategories.reduce((sum, category) => sum + (data[category as keyof BudgetFormValues] as number || 0), 0);

    // Calculate percentages
    const needsPercent = (needs / income) * 100;
    const wantsPercent = (wants / income) * 100;
    const savingsPercent = (savings / income) * 100;

    // Calculate recommended amounts based on 50/30/20 rule
    const needsRecommended = income * 0.5;
    const wantsRecommended = income * 0.3;
    const savingsRecommended = income * 0.2;

    // Calculate differences from recommended
    const needsDifference = needsRecommended - needs;
    const wantsDifference = wantsRecommended - wants;
    const savingsDifference = savingsRecommended - savings;

    setBudgetResults({
      needs,
      wants,
      savings,
      needsPercent,
      wantsPercent,
      savingsPercent,
      needsRecommended,
      wantsRecommended,
      savingsRecommended,
      needsDifference,
      wantsDifference,
      savingsDifference
    });

    // Save the budget if user is logged in
    if (user) {
      saveBudget.mutate(data);
    }
  };

  const onSubmit = (data: BudgetFormValues) => {
    calculateBudget(data);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const getBudgetStatus = (actual: number, recommended: number) => {
    const difference = actual - recommended;
    const percentDiff = (difference / recommended) * 100;
    
    if (Math.abs(percentDiff) < 10) {
      return "balanced"; // Within 10% of recommendation
    } else if (difference > 0) {
      return "high"; // More than 10% over recommendation
    } else {
      return "low"; // More than 10% under recommendation
    }
  };

  const getProgressColor = (category: 'needs' | 'wants' | 'savings') => {
    if (!budgetResults) return "bg-primary";
    
    let actual, recommended;
    
    if (category === 'needs') {
      actual = budgetResults.needsPercent;
      recommended = 50;
    } else if (category === 'wants') {
      actual = budgetResults.wantsPercent;
      recommended = 30;
    } else {
      actual = budgetResults.savingsPercent;
      recommended = 20;
    }
    
    const status = getBudgetStatus(actual, recommended);
    
    if (status === "balanced") return "bg-primary";
    if (status === "high") return "bg-destructive";
    return "bg-amber-500";
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>50/30/20 Budget Calculator</CardTitle>
          <CardDescription>
            Plan your budget using the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="income"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Monthly Income</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                        <Input
                          {...field}
                          type="number"
                          className="pl-7"
                          placeholder="Your monthly income"
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div>
                <h3 className="font-medium mb-2">Needs (50%)</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {needsCategories.map((category) => (
                    <FormField
                      key={category}
                      control={form.control}
                      name={category as keyof BudgetFormValues}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="capitalize">{category}</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                              <Input
                                {...field}
                                type="number"
                                className="pl-7"
                                placeholder={`Monthly ${category}`}
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Wants (30%)</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {wantsCategories.map((category) => (
                    <FormField
                      key={category}
                      control={form.control}
                      name={category as keyof BudgetFormValues}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="capitalize">{category}</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                              <Input
                                {...field}
                                type="number"
                                className="pl-7"
                                placeholder={`Monthly ${category}`}
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Savings & Investments (20%)</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {savingsCategories.map((category) => (
                    <FormField
                      key={category}
                      control={form.control}
                      name={category as keyof BudgetFormValues}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="capitalize">{category}</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                              <Input
                                {...field}
                                type="number"
                                className="pl-7"
                                placeholder={`Monthly ${category}`}
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
              </div>

              <Button type="submit" className="w-full">Calculate Budget</Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      <Card className={budgetResults ? "" : "opacity-50"}>
        <CardHeader>
          <CardTitle>Your Budget Analysis</CardTitle>
          <CardDescription>
            How your spending compares to the 50/30/20 rule recommendations.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {!budgetResults ? (
            <p className="text-center py-10 text-muted-foreground">
              Fill out the budget calculator to see your analysis.
            </p>
          ) : (
            <>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <div className="font-medium">Needs</div>
                    <div className="text-sm text-muted-foreground">
                      {budgetResults.needsPercent.toFixed(1)}% of income
                    </div>
                  </div>
                  <CustomProgress
                    value={Math.min(100, budgetResults.needsPercent)}
                    className="h-2"
                    indicatorClassName={getProgressColor('needs')}
                  />
                  <div className="flex justify-between text-sm mt-1">
                    <div>{formatCurrency(budgetResults.needs)}</div>
                    <div className="text-muted-foreground">Target: 50%</div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <div className="font-medium">Wants</div>
                    <div className="text-sm text-muted-foreground">
                      {budgetResults.wantsPercent.toFixed(1)}% of income
                    </div>
                  </div>
                  <CustomProgress
                    value={Math.min(100, budgetResults.wantsPercent)}
                    className="h-2"
                    indicatorClassName={getProgressColor('wants')}
                  />
                  <div className="flex justify-between text-sm mt-1">
                    <div>{formatCurrency(budgetResults.wants)}</div>
                    <div className="text-muted-foreground">Target: 30%</div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <div className="font-medium">Savings</div>
                    <div className="text-sm text-muted-foreground">
                      {budgetResults.savingsPercent.toFixed(1)}% of income
                    </div>
                  </div>
                  <CustomProgress
                    value={Math.min(100, budgetResults.savingsPercent)}
                    className="h-2"
                    indicatorClassName={getProgressColor('savings')}
                  />
                  <div className="flex justify-between text-sm mt-1">
                    <div>{formatCurrency(budgetResults.savings)}</div>
                    <div className="text-muted-foreground">Target: 20%</div>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <h3 className="font-medium">Recommendations</h3>
                
                <div className={`p-3 rounded-md border ${Math.abs(budgetResults.needsDifference) < budgetResults.needsRecommended * 0.1 ? "bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800" : "bg-amber-50 border-amber-200 dark:bg-amber-950 dark:border-amber-800"}`}>
                  <h4 className="font-medium">Needs</h4>
                  {Math.abs(budgetResults.needsDifference) < budgetResults.needsRecommended * 0.1 ? (
                    <p className="text-sm">Your essential spending is well-balanced at around 50% of your income.</p>
                  ) : budgetResults.needsDifference > 0 ? (
                    <p className="text-sm">You're spending {formatCurrency(Math.abs(budgetResults.needsDifference))} less than recommended on needs. Ensure your essential needs are adequately covered.</p>
                  ) : (
                    <p className="text-sm">Consider reducing your essential spending by {formatCurrency(Math.abs(budgetResults.needsDifference))} to achieve a better balance.</p>
                  )}
                </div>
                
                <div className={`p-3 rounded-md border ${Math.abs(budgetResults.wantsDifference) < budgetResults.wantsRecommended * 0.1 ? "bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800" : "bg-amber-50 border-amber-200 dark:bg-amber-950 dark:border-amber-800"}`}>
                  <h4 className="font-medium">Wants</h4>
                  {Math.abs(budgetResults.wantsDifference) < budgetResults.wantsRecommended * 0.1 ? (
                    <p className="text-sm">Your discretionary spending is well-balanced at around 30% of your income.</p>
                  ) : budgetResults.wantsDifference > 0 ? (
                    <p className="text-sm">You're spending {formatCurrency(Math.abs(budgetResults.wantsDifference))} less than recommended on wants. It's okay to enjoy your money responsibly.</p>
                  ) : (
                    <p className="text-sm">Consider reducing your discretionary spending by {formatCurrency(Math.abs(budgetResults.wantsDifference))} to avoid lifestyle inflation.</p>
                  )}
                </div>
                
                <div className={`p-3 rounded-md border ${Math.abs(budgetResults.savingsDifference) < budgetResults.savingsRecommended * 0.1 ? "bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800" : budgetResults.savingsDifference < 0 ? "bg-destructive/10 border-destructive/20" : "bg-amber-50 border-amber-200 dark:bg-amber-950 dark:border-amber-800"}`}>
                  <h4 className="font-medium">Savings</h4>
                  {Math.abs(budgetResults.savingsDifference) < budgetResults.savingsRecommended * 0.1 ? (
                    <p className="text-sm">Your savings rate is excellent at around 20% of your income.</p>
                  ) : budgetResults.savingsDifference > 0 ? (
                    <p className="text-sm">Try to increase your savings by {formatCurrency(Math.abs(budgetResults.savingsDifference))} to build better financial security.</p>
                  ) : (
                    <p className="text-sm">Your savings rate is higher than the recommendation by {formatCurrency(Math.abs(budgetResults.savingsDifference))}. Great job!</p>
                  )}
                </div>
              </div>
            </>
          )}
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <p className="text-sm text-muted-foreground">The 50/30/20 rule is a guideline to help you allocate your income: 50% for needs, 30% for wants, and 20% for savings and debt repayment.</p>
          
          {budgetResults && budgetResults.savings > 100 && onInvestSavings && (
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => onInvestSavings(budgetResults.savings, 'USD')}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Invest My Savings: {formatCurrency(budgetResults.savings)}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default BudgetCalculator;