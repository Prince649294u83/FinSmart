import { Link } from "wouter";
import { Facebook, Instagram, Twitter, Linkedin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-neutral-800">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8 xl:col-span-1">
            <span className="text-white font-bold text-2xl">FinSmart</span>
            <p className="text-neutral-300 text-base leading-6">
              Making financial technology accessible for everyone. Our mission is to help you better understand money, save smarter, and access financial services easily.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-neutral-400 hover:text-neutral-300">
                <span className="sr-only">Facebook</span>
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-neutral-300">
                <span className="sr-only">Instagram</span>
                <Instagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-neutral-300">
                <span className="sr-only">Twitter</span>
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-neutral-300">
                <span className="sr-only">LinkedIn</span>
                <Linkedin className="h-6 w-6" />
              </a>
            </div>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-neutral-200 tracking-wider uppercase">
                  Tools
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/tools#budget-calculator">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Budget Calculator
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/tools#savings-goal-tracker">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Savings Goal Tracker
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/tools#financial-health-quiz">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Financial Health Quiz
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/tools#expense-categorization">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Expense Categorization
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-neutral-200 tracking-wider uppercase">
                  Learn
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/learn#budgeting">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Budgeting Basics
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/learn#saving">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Saving Strategies
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/learn#investing">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Investing 101
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/learn#debt">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Debt Management
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-neutral-200 tracking-wider uppercase">
                  Company
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/resources#about">
                      <a className="text-base text-neutral-300 hover:text-white">
                        About
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources#team">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Team
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources#blog">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Blog
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources#careers">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Careers
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-neutral-200 tracking-wider uppercase">
                  Legal
                </h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/resources#privacy">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Privacy
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources#terms">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Terms
                      </a>
                    </Link>
                  </li>
                  <li>
                    <Link href="/resources#accessibility">
                      <a className="text-base text-neutral-300 hover:text-white">
                        Accessibility
                      </a>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-neutral-700 pt-8">
          <p className="text-base text-neutral-400 text-center">
            &copy; {new Date().getFullYear()} FinSmart Technologies. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
