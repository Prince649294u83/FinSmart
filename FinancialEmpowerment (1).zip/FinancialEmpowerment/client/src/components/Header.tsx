import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, User, LogOut, Loader2, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useTheme } from "@/hooks/use-theme";

const Header = () => {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const isActive = (path: string) => {
    return location === path;
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Get initials from username or fullname if available
  const getInitials = () => {
    if (!user) return "U";
    
    // If user has a fullName property and it's a non-empty string
    if (user.fullName && typeof user.fullName === 'string' && user.fullName.trim() !== '') {
      const names = user.fullName.split(' ');
      if (names.length >= 2) {
        return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
      }
      return user.fullName.substring(0, 2).toUpperCase();
    }
    
    // Default to username initials
    return user.username.substring(0, 2).toUpperCase();
  };

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <span className="text-primary dark:text-primary-400 font-bold text-2xl cursor-pointer">FinSmart</span>
              </Link>
            </div>
            <nav className="hidden sm:ml-6 sm:flex sm:space-x-8" aria-label="Main Navigation">
              <Link href="/">
                <span className={`${isActive("/") ? "border-primary text-neutral-900 dark:text-white" : "border-transparent hover:border-neutral-300 text-neutral-500 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100"} px-1 pt-1 border-b-2 font-medium cursor-pointer`}>
                  Home
                </span>
              </Link>
              <Link href="/learn">
                <span className={`${isActive("/learn") || isActive("/courses/list") || location.includes("/courses/") ? "border-primary text-neutral-900 dark:text-white" : "border-transparent hover:border-neutral-300 text-neutral-500 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100"} px-1 pt-1 border-b-2 font-medium cursor-pointer`}>
                  Learn
                </span>
              </Link>
              <Link href="/tools">
                <span className={`${isActive("/tools") ? "border-primary text-neutral-900 dark:text-white" : "border-transparent hover:border-neutral-300 text-neutral-500 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100"} px-1 pt-1 border-b-2 font-medium cursor-pointer`}>
                  Tools
                </span>
              </Link>
              <Link href="/resources">
                <span className={`${isActive("/resources") ? "border-primary text-neutral-900 dark:text-white" : "border-transparent hover:border-neutral-300 text-neutral-500 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100"} px-1 pt-1 border-b-2 font-medium cursor-pointer`}>
                  Resources
                </span>
              </Link>
              <Link href="/analytics">
                <span className={`${isActive("/analytics") ? "border-primary text-neutral-900 dark:text-white" : "border-transparent hover:border-neutral-300 text-neutral-500 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100"} px-1 pt-1 border-b-2 font-medium cursor-pointer flex items-center`}>
                  <BarChart3 className="h-4 w-4 mr-1" />
                  Analytics
                </span>
              </Link>
            </nav>
          </div>
          <div className="hidden sm:flex items-center space-x-2">
            <ThemeToggle />
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="p-0 h-8 w-8 rounded-full">
                    <Avatar>
                      <AvatarFallback>{getInitials()}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem className="cursor-default font-medium">
                    <User className="mr-2 h-4 w-4" />
                    <span>{user.fullName || user.username}</span>
                  </DropdownMenuItem>
                  <Link href="/profile">
                    <DropdownMenuItem className="cursor-pointer">
                      <User className="mr-2 h-4 w-4" />
                      <span>My Profile</span>
                    </DropdownMenuItem>
                  </Link>
                  <DropdownMenuItem onClick={handleLogout} className="text-red-600 cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth">
                <Button className="bg-primary hover:bg-primary-600">
                  Get Started
                </Button>
              </Link>
            )}
          </div>
          <div className="flex items-center sm:hidden">
            <button
              type="button"
              className="text-neutral-500 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-white focus:outline-none"
              onClick={toggleMobileMenu}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="sm:hidden bg-white dark:bg-gray-900">
          <div className="pt-2 pb-3 space-y-1">
            <Link href="/">
              <span className={`${isActive("/") ? "bg-primary-100 dark:bg-primary-900 text-primary border-primary" : "text-neutral-500 hover:bg-neutral-100 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100 dark:hover:bg-gray-800 border-transparent"} block pl-3 pr-4 py-2 border-l-4 font-medium cursor-pointer`}>
                Home
              </span>
            </Link>
            <Link href="/learn">
              <span className={`${isActive("/learn") || isActive("/courses/list") || location.includes("/courses/") ? "bg-primary-100 dark:bg-primary-900 text-primary border-primary" : "text-neutral-500 hover:bg-neutral-100 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100 dark:hover:bg-gray-800 border-transparent"} block pl-3 pr-4 py-2 border-l-4 font-medium cursor-pointer`}>
                Learn
              </span>
            </Link>
            <Link href="/tools">
              <span className={`${isActive("/tools") ? "bg-primary-100 dark:bg-primary-900 text-primary border-primary" : "text-neutral-500 hover:bg-neutral-100 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100 dark:hover:bg-gray-800 border-transparent"} block pl-3 pr-4 py-2 border-l-4 font-medium cursor-pointer`}>
                Tools
              </span>
            </Link>
            <Link href="/resources">
              <span className={`${isActive("/resources") ? "bg-primary-100 dark:bg-primary-900 text-primary border-primary" : "text-neutral-500 hover:bg-neutral-100 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100 dark:hover:bg-gray-800 border-transparent"} block pl-3 pr-4 py-2 border-l-4 font-medium cursor-pointer`}>
                Resources
              </span>
            </Link>
            <Link href="/analytics">
              <span className={`${isActive("/analytics") ? "bg-primary-100 dark:bg-primary-900 text-primary border-primary" : "text-neutral-500 hover:bg-neutral-100 hover:text-neutral-700 dark:text-gray-300 dark:hover:text-gray-100 dark:hover:bg-gray-800 border-transparent"} block pl-3 pr-4 py-2 border-l-4 font-medium cursor-pointer flex items-center`}>
                <BarChart3 className="h-4 w-4 mr-2" />
                Analytics
              </span>
            </Link>
          </div>
          <div className="pt-4 pb-3 border-t border-neutral-200 dark:border-gray-700">
            <div className="px-3 mb-3 flex justify-end">
              <ThemeToggle showTooltip={false} />
            </div>
            {user ? (
              <div className="space-y-3 px-3">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>{getInitials()}</AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="ml-3">
                    <div className="text-base font-medium">{user.fullName || user.username}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{user.email}</div>
                  </div>
                </div>
                <Link href="/profile">
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center justify-center mb-2"
                  >
                    <User className="mr-2 h-4 w-4" />
                    My Profile
                  </Button>
                </Link>
                <Button 
                  variant="destructive" 
                  className="w-full flex items-center justify-center"
                  onClick={handleLogout}
                  disabled={logoutMutation.isPending}
                >
                  {logoutMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Logging out...
                    </>
                  ) : (
                    <>
                      <LogOut className="mr-2 h-4 w-4" />
                      Logout
                    </>
                  )}
                </Button>
              </div>
            ) : (
              <div className="px-3">
                <Link href="/auth">
                  <Button className="w-full bg-primary hover:bg-primary-600">
                    Get Started
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
