import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

// Financial learning resources with links to real-world famous websites
const resources = [
  {
    id: "budgeting",
    category: "Basics",
    title: "Budgeting 101: Setting Up Your First Budget",
    description: "Learn how to create a simple budget that helps you take control of your finances and reach your goals.",
    imageSrc: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    imageAlt: "Person creating a budget",
    externalUrl: "https://www.nerdwallet.com/article/finance/how-to-budget",
    externalSite: "NerdWallet",
  },
  {
    id: "savings",
    category: "Saving",
    title: "The 50/30/20 Rule: Simple Saving Strategy",
    description: "Discover how to divide your income into needs, wants, and savings to build financial security.",
    imageSrc: "https://images.unsplash.com/photo-1565514158740-064f34bd6cfd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    imageAlt: "Savings concept with piggy bank",
    externalUrl: "https://www.investopedia.com/ask/answers/022916/what-502030-budget-rule.asp",
    externalSite: "Investopedia",
  },
  {
    id: "investing",
    category: "Investing",
    title: "Investing Basics: Start with Small Amounts",
    description: "Learn how to begin investing with just a few dollars and build wealth over time.",
    imageSrc: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    imageAlt: "Stock market data",
    externalUrl: "https://www.fool.com/investing/how-to-invest/",
    externalSite: "The Motley Fool",
  },
  {
    id: "debt",
    category: "Debt Management",
    title: "Smart Debt Repayment Strategies",
    description: "Learn effective methods to tackle your debt and become financially free.",
    imageSrc: "https://images.unsplash.com/photo-1579621970795-87facc2f976d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    imageAlt: "Person reviewing bills and financial documents",
    externalUrl: "https://www.ramseysolutions.com/debt/how-to-pay-off-debt",
    externalSite: "Ramsey Solutions",
  },
  {
    id: "credit",
    category: "Credit",
    title: "Understanding and Improving Your Credit Score",
    description: "Learn what affects your credit score and how to improve it over time.",
    imageSrc: "https://images.unsplash.com/photo-1574607383476-f517f260d30b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    imageAlt: "Credit card and financial documents",
    externalUrl: "https://www.experian.com/blogs/ask-experian/credit-education/score-basics/what-is-a-good-credit-score/",
    externalSite: "Experian",
  },
  {
    id: "retirement",
    category: "Planning",
    title: "Retirement Planning for Beginners",
    description: "Start planning for retirement early with these simple, effective strategies.",
    imageSrc: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    imageAlt: "Elderly couple enjoying retirement",
    externalUrl: "https://www.fidelity.com/viewpoints/retirement/how-to-start-planning-for-retirement",
    externalSite: "Fidelity",
  }
];

interface LearningResourcesProps {
  limit?: number;
  showViewAll?: boolean;
}

const LearningResources = ({ limit, showViewAll = true }: LearningResourcesProps) => {
  // If limit is provided, slice the resources array
  const displayResources = limit ? resources.slice(0, limit) : resources;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center">
        <h2 className="text-base font-semibold text-primary uppercase tracking-wide">Learning Center</h2>
        <p className="mt-2 text-3xl font-extrabold text-neutral-900 sm:text-4xl">
          Financial Education Made Simple
        </p>
        <p className="mt-4 max-w-2xl text-xl text-neutral-500 mx-auto">
          Browse our free resources to build your financial knowledge.
        </p>
      </div>

      <div className="mt-12 grid gap-5 max-w-lg mx-auto lg:grid-cols-3 lg:max-w-none">
        {displayResources.map((resource) => (
          <Card 
            key={resource.id} 
            className="flex flex-col rounded-lg shadow-sm overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-1"
          >
            <div className="flex-shrink-0">
              <img 
                className="h-48 w-full object-cover" 
                src={resource.imageSrc} 
                alt={resource.imageAlt} 
              />
            </div>
            <CardContent className="flex-1 bg-white p-6 flex flex-col justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-primary">
                  {resource.category}
                </p>
                <div className="block mt-2">
                  <p className="text-xl font-semibold text-neutral-900">
                    {resource.title}
                  </p>
                  <p className="mt-3 text-base text-neutral-500">
                    {resource.description}
                  </p>
                </div>
              </div>
              <div className="mt-6 flex items-center justify-between">
                <div>
                  <span className="text-sm text-neutral-500">Source: </span>
                  <a 
                    href={resource.externalUrl} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-sm font-medium text-primary hover:underline"
                  >
                    {resource.externalSite}
                  </a>
                </div>
                <div>
                  <a 
                    href={resource.externalUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <Button variant="outline" className="text-primary border-neutral-300 hover:bg-neutral-50">
                      Read Article
                    </Button>
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {showViewAll && (
        <div className="mt-12 text-center">
          <Link href="/learn">
            <Button className="bg-primary hover:bg-primary-600">
              View All Learning Resources
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default LearningResources;
