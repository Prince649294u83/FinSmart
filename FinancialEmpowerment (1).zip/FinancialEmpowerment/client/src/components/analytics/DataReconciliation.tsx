import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2, RefreshCw, Check, XCircle, AlertCircle } from "lucide-react";

interface DataSource {
  id: string;
  name: string;
  status: 'connected' | 'disconnected' | 'pending' | 'error';
  lastSync?: string;
  count?: number;
}

interface DataReconciliationProps {
  onReconcileComplete?: () => void;
}

export function DataReconciliation({ onReconcileComplete }: DataReconciliationProps) {
  const [dataSources, setDataSources] = useState<DataSource[]>([
    { 
      id: "bank", 
      name: "Bank Transactions", 
      status: "connected",
      lastSync: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      count: 245
    },
    { 
      id: "investment", 
      name: "Investment Portfolio", 
      status: "connected",
      lastSync: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      count: 42
    },
    { 
      id: "credit", 
      name: "Credit Card", 
      status: "disconnected"
    },
    { 
      id: "savings", 
      name: "Savings Goals", 
      status: "connected",
      lastSync: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      count: 5
    }
  ]);

  const [isReconciling, setIsReconciling] = useState(false);
  const { toast } = useToast();

  const reconcileData = async () => {
    setIsReconciling(true);
    
    // Simulate data reconciliation process
    const updatedDataSources = [...dataSources];
    
    // Update statuses to pending
    updatedDataSources.forEach(source => {
      if (source.status === 'connected') {
        source.status = 'pending';
      }
    });
    setDataSources(updatedDataSources);
    
    // Process each source with slight delays to show progress
    for (let i = 0; i < updatedDataSources.length; i++) {
      const source = updatedDataSources[i];
      if (source.status === 'pending') {
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Simulate success or occasional error
        const isSuccess = Math.random() > 0.2;
        if (isSuccess) {
          source.status = 'connected';
          source.lastSync = new Date().toISOString();
          if (source.count) {
            source.count += Math.floor(Math.random() * 5) + 1;
          } else {
            source.count = Math.floor(Math.random() * 10) + 1;
          }
        } else {
          source.status = 'error';
        }
        
        setDataSources([...updatedDataSources]);
      }
    }
    
    setIsReconciling(false);
    
    // Count errors
    const errorCount = updatedDataSources.filter(s => s.status === 'error').length;
    
    if (errorCount === 0) {
      toast({
        title: "Data Reconciliation Complete",
        description: "All data sources successfully synchronized.",
        variant: "default",
      });
    } else {
      toast({
        title: "Data Reconciliation Completed with Errors",
        description: `${errorCount} sources failed to synchronize. Please try again.`,
        variant: "destructive",
      });
    }
    
    if (onReconcileComplete) {
      onReconcileComplete();
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
        return <Check className="h-4 w-4 text-green-500" />;
      case 'disconnected':
        return <XCircle className="h-4 w-4 text-gray-400" />;
      case 'pending':
        return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Data Management</CardTitle>
        <CardDescription>
          Manage and reconcile data from all your connected financial sources
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {dataSources.map((source) => (
            <div key={source.id} className="flex items-center justify-between p-3 border rounded-md">
              <div className="flex items-center space-x-3">
                {getStatusIcon(source.status)}
                <div>
                  <h4 className="text-sm font-medium">{source.name}</h4>
                  {source.lastSync && (
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Last updated: {new Date(source.lastSync).toLocaleDateString()}{' '}
                      {source.count && `(${source.count} records)`}
                    </p>
                  )}
                </div>
              </div>
              {source.status === 'disconnected' && (
                <Button variant="outline" size="sm">
                  Connect
                </Button>
              )}
              {source.status === 'error' && (
                <Button variant="destructive" size="sm">
                  Retry
                </Button>
              )}
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button onClick={reconcileData} disabled={isReconciling}>
          {isReconciling ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Syncing...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" />
              Sync All Data
            </>
          )}
        </Button>
        <Button variant="outline" disabled={isReconciling}>
          Add Data Source
        </Button>
      </CardFooter>
    </Card>
  );
}