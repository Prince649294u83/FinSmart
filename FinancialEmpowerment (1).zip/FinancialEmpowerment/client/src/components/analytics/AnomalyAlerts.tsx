import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { AlertTriangle, CheckCircle, Bell, ArrowRight } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from '@/hooks/use-toast';

// Alert severity colors
const severityColors = {
  low: "bg-yellow-500 hover:bg-yellow-600",
  medium: "bg-orange-500 hover:bg-orange-600",
  high: "bg-red-500 hover:bg-red-600",
};

type AnomalyAlertType = {
  id: number;
  userId: number;
  type: string;
  severity: 'low' | 'medium' | 'high';
  description: string;
  data: any;
  isRead: boolean;
  isResolved: boolean;
  createdAt: string;
};

// Format the alert type for display
const formatAlertType = (type: string) => {
  return type
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

// Individual alert component
export function AnomalyAlertCard({ alert, onMarkRead, onResolve }: { 
  alert: AnomalyAlertType, 
  onMarkRead: (id: number) => void,
  onResolve: (id: number) => void
}) {
  return (
    <Card className={`w-full ${!alert.isRead ? 'border-l-4 border-l-blue-500' : ''}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className={`h-5 w-5 ${
              alert.severity === 'high' ? 'text-red-500' : 
              alert.severity === 'medium' ? 'text-orange-500' : 'text-yellow-500'
            }`} />
            <CardTitle className="text-lg">{formatAlertType(alert.type)}</CardTitle>
          </div>
          <Badge className={severityColors[alert.severity]}>
            {alert.severity.toUpperCase()}
          </Badge>
        </div>
        <CardDescription className="pt-1">
          {new Date(alert.createdAt).toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm">{alert.description}</p>
        {alert.data?.details && (
          <div className="mt-2 p-2 bg-muted rounded-md text-xs">
            <p className="font-medium mb-1">Additional Details:</p>
            <ul className="list-disc list-inside">
              {Object.entries(alert.data.details).map(([key, value]) => (
                <li key={key}>{key}: {String(value)}</li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
      <Separator />
      <CardFooter className="pt-4 flex justify-between">
        {!alert.isRead ? (
          <Button variant="outline" size="sm" onClick={() => onMarkRead(alert.id)}>
            Mark as Read
          </Button>
        ) : (
          <span className="text-sm text-muted-foreground flex items-center">
            <CheckCircle className="h-4 w-4 mr-1" /> Read
          </span>
        )}
        {!alert.isResolved && (
          <Button variant="default" size="sm" onClick={() => onResolve(alert.id)}>
            Resolve Issue
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}

// Main anomaly alerts component
export function AnomalyAlerts() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showAll, setShowAll] = useState(false);
  const queryClient = useQueryClient();
  
  // Get alerts from API
  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ['/api/analytics/alerts', { userId: user?.id, unreadOnly: !showAll }],
    queryFn: async ({ queryKey }) => {
      const [_, { userId, unreadOnly }] = queryKey as [string, { userId: number, unreadOnly: boolean }];
      const res = await fetch(`/api/analytics/alerts?userId=${userId}&unreadOnly=${unreadOnly}`);
      if (!res.ok) throw new Error('Failed to fetch alerts');
      return res.json();
    },
    enabled: !!user?.id,
  });
  
  // Mark alert as read
  const markReadMutation = useMutation({
    mutationFn: async (alertId: number) => {
      const res = await apiRequest('PUT', `/api/analytics/alerts/${alertId}`, {
        isRead: true
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/analytics/alerts'] });
      toast({
        title: "Alert updated",
        description: "The alert has been marked as read.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update alert",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Resolve alert
  const resolveAlertMutation = useMutation({
    mutationFn: async (alertId: number) => {
      const res = await apiRequest('PUT', `/api/analytics/alerts/${alertId}`, {
        isResolved: true,
        isRead: true
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/analytics/alerts'] });
      toast({
        title: "Alert resolved",
        description: "The alert has been marked as resolved.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to resolve alert",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  const handleMarkRead = (alertId: number) => {
    markReadMutation.mutate(alertId);
  };
  
  const handleResolve = (alertId: number) => {
    resolveAlertMutation.mutate(alertId);
  };
  
  const unreadCount = alerts.filter((alert: AnomalyAlertType) => !alert.isRead).length;
  
  if (isLoading) {
    return (
      <div className="w-full flex justify-center p-8">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }
  
  return (
    <div className="w-full space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <h2 className="text-2xl font-bold">Anomaly Alerts</h2>
          {unreadCount > 0 && !showAll && (
            <Badge variant="destructive">{unreadCount} new</Badge>
          )}
        </div>
        <Button 
          variant="ghost" 
          onClick={() => setShowAll(!showAll)}
          className="flex items-center gap-1"
        >
          {showAll ? "Show Unread Only" : "Show All Alerts"} 
          <ArrowRight className="h-4 w-4 ml-1" />
        </Button>
      </div>
      
      {alerts.length === 0 ? (
        <Card className="w-full">
          <CardContent className="flex flex-col items-center justify-center p-8">
            <Bell className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-center text-muted-foreground">
              {showAll 
                ? "No alerts found. You're doing great!" 
                : "No unread alerts. Check 'Show All Alerts' to view past alerts."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {alerts.map((alert: AnomalyAlertType) => (
            <AnomalyAlertCard 
              key={alert.id} 
              alert={alert} 
              onMarkRead={handleMarkRead}
              onResolve={handleResolve}
            />
          ))}
        </div>
      )}
    </div>
  );
}