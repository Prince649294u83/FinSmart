import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { useTheme } from '@/hooks/use-theme';

// Define color palettes
const COLORS = {
  light: ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#A28AFF', '#FF6B8B', '#63C9B4', '#F7C244'],
  dark: ['#00A8FF', '#00E5B5', '#FFD642', '#FF9B61', '#B8A2FF', '#FF89A6', '#7EDECB', '#FFDA6A']
};

// Custom tooltip formatter
const tooltipFormatter = (value: number) => {
  return [`$${value.toLocaleString()}`, 'Amount'];
};

// Spending by Category Chart
export function SpendingByCategoryChart({ data }: { data: any[] }) {
  const { theme } = useTheme();
  const colors = theme === 'dark' ? COLORS.dark : COLORS.light;
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Spending by Category</CardTitle>
        <CardDescription>Breakdown of your expenses by category</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={true}
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
              ))}
            </Pie>
            <Tooltip formatter={tooltipFormatter} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

// Monthly Spending Chart
export function MonthlySpendingChart({ data }: { data: any[] }) {
  const { theme } = useTheme();
  const barColor = theme === 'dark' ? '#00E5B5' : '#00C49F';
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Monthly Spending</CardTitle>
        <CardDescription>Track your spending patterns over time</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip formatter={tooltipFormatter} />
            <Legend />
            <Bar dataKey="amount" fill={barColor} name="Amount Spent" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

// Investment Performance Chart
export function InvestmentPerformanceChart({ data }: { data: any[] }) {
  const { theme } = useTheme();
  const lineColor = theme === 'dark' ? '#B8A2FF' : '#A28AFF';
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Investment Performance</CardTitle>
        <CardDescription>Growth of your investments over time</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip formatter={tooltipFormatter} />
            <Legend />
            <Line type="monotone" dataKey="value" stroke={lineColor} activeDot={{ r: 8 }} name="Portfolio Value" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

// Goal Progress Chart
export function GoalProgressChart({ data }: { data: any[] }) {
  const { theme } = useTheme();
  const colors = theme === 'dark' ? COLORS.dark : COLORS.light;
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Savings Goal Progress</CardTitle>
        <CardDescription>Track your progress towards financial goals</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} layout="vertical" margin={{ top: 5, right: 20, left: 50, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" />
            <YAxis dataKey="name" type="category" />
            <Tooltip />
            <Legend />
            <Bar dataKey="current" stackId="a" fill={colors[0]} name="Current Amount" />
            <Bar dataKey="remaining" stackId="a" fill={colors[1]} name="Remaining" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

// Analytics Dashboard with Tabs
export function AnalyticsDashboard({
  spendingCategoryData,
  monthlySpendingData,
  investmentData,
  goalData
}: {
  spendingCategoryData: any[];
  monthlySpendingData: any[];
  investmentData: any[];
  goalData: any[];
}) {
  const [activeTab, setActiveTab] = useState("spending");
  
  return (
    <div className="w-full space-y-4">
      <Tabs defaultValue="spending" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="spending">Spending</TabsTrigger>
          <TabsTrigger value="investments">Investments</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
          <TabsTrigger value="all">Overview</TabsTrigger>
        </TabsList>
        
        <TabsContent value="spending" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <SpendingByCategoryChart data={spendingCategoryData} />
            <MonthlySpendingChart data={monthlySpendingData} />
          </div>
        </TabsContent>
        
        <TabsContent value="investments" className="space-y-4 pt-4">
          <InvestmentPerformanceChart data={investmentData} />
        </TabsContent>
        
        <TabsContent value="goals" className="space-y-4 pt-4">
          <GoalProgressChart data={goalData} />
        </TabsContent>
        
        <TabsContent value="all" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <SpendingByCategoryChart data={spendingCategoryData} />
            <MonthlySpendingChart data={monthlySpendingData} />
            <InvestmentPerformanceChart data={investmentData} />
            <GoalProgressChart data={goalData} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}