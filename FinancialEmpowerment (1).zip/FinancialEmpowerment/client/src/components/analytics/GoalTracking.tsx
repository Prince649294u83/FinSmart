import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, Check, Target, TrendingUp, Calendar, RefreshCcw } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

type SavingsGoal = {
  id: number;
  userId: number;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  createdAt: string;
};

type GoalUpdate = {
  id: number;
  goalId: number;
  userId: number;
  previousAmount: number;
  newAmount: number;
  changeAmount: number;
  note: string;
  updatedAt: string;
};

// Calculate remaining days until target date
const getRemainingDays = (targetDate: string) => {
  const target = new Date(targetDate);
  const today = new Date();
  const diffTime = target.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

// Get progress percentage
const getProgressPercentage = (current: number, target: number) => {
  return Math.min(Math.round((current / target) * 100), 100);
};

// Format date for display
const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

// Get status badge based on progress and remaining days
const getStatusBadge = (currentAmount: number, targetAmount: number, targetDate: string) => {
  const percent = getProgressPercentage(currentAmount, targetAmount);
  const remainingDays = getRemainingDays(targetDate);
  
  if (percent >= 100) {
    return <Badge className="bg-green-500">Completed</Badge>;
  }
  
  if (remainingDays < 0) {
    return <Badge variant="destructive">Overdue</Badge>;
  }
  
  if (remainingDays < 30 && percent < 70) {
    return <Badge variant="destructive">At Risk</Badge>;
  }
  
  if (percent > 50) {
    return <Badge className="bg-emerald-500">On Track</Badge>;
  }
  
  return <Badge variant="secondary">In Progress</Badge>;
};

// Individual goal card component
export function GoalCard({ goal, updates }: { goal: SavingsGoal, updates: GoalUpdate[] }) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [updateAmount, setUpdateAmount] = useState('');
  const [updateNote, setUpdateNote] = useState('');
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const progressPercent = getProgressPercentage(goal.currentAmount, goal.targetAmount);
  const remainingDays = getRemainingDays(goal.targetDate);
  const recentUpdates = updates.slice(0, 3); // Show only 3 most recent updates
  
  // Update goal mutation
  const updateGoalMutation = useMutation({
    mutationFn: async (data: { previousAmount: number, newAmount: number, note: string }) => {
      // First update the goal
      const goalRes = await apiRequest('PUT', `/api/savings-goals/${goal.id}`, {
        currentAmount: data.newAmount
      });
      
      if (!goalRes.ok) {
        throw new Error('Failed to update goal');
      }
      
      // Then create a goal update record
      const updateRes = await apiRequest('POST', `/api/goal-updates`, {
        goalId: goal.id,
        userId: goal.userId,
        previousAmount: data.previousAmount,
        newAmount: data.newAmount,
        changeAmount: data.newAmount - data.previousAmount,
        note: data.note
      });
      
      if (!updateRes.ok) {
        throw new Error('Failed to record goal update');
      }
      
      return updateRes.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/savings-goals'] });
      queryClient.invalidateQueries({ queryKey: ['/api/goal-updates'] });
      setIsDialogOpen(false);
      setUpdateAmount('');
      setUpdateNote('');
      toast({
        title: "Goal updated",
        description: "Your savings goal has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update goal",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  const handleUpdateGoal = () => {
    const newAmount = parseFloat(updateAmount);
    
    if (isNaN(newAmount)) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid number.",
        variant: "destructive"
      });
      return;
    }
    
    updateGoalMutation.mutate({
      previousAmount: goal.currentAmount,
      newAmount: newAmount,
      note: updateNote
    });
  };
  
  return (
    <>
      <Card className="w-full">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-xl">{goal.name}</CardTitle>
              <CardDescription className="mt-1">
                Created on {formatDate(goal.createdAt)}
              </CardDescription>
            </div>
            {getStatusBadge(goal.currentAmount, goal.targetAmount, goal.targetDate)}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span className="font-medium">{progressPercent}%</span>
            </div>
            <Progress value={progressPercent} className="h-2" />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-muted p-3 rounded-lg">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <Target className="h-4 w-4" />
                <span>Target</span>
              </div>
              <p className="font-semibold">${goal.targetAmount.toLocaleString()}</p>
            </div>
            <div className="bg-muted p-3 rounded-lg">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <TrendingUp className="h-4 w-4" />
                <span>Current</span>
              </div>
              <p className="font-semibold">${goal.currentAmount.toLocaleString()}</p>
            </div>
            <div className="bg-muted p-3 rounded-lg">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <Calendar className="h-4 w-4" />
                <span>Target Date</span>
              </div>
              <p className="font-semibold">{formatDate(goal.targetDate)}</p>
            </div>
            <div className="bg-muted p-3 rounded-lg">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <AlertCircle className="h-4 w-4" />
                <span>Remaining</span>
              </div>
              <p className={`font-semibold ${remainingDays < 0 ? 'text-red-500' : ''}`}>
                {remainingDays < 0 ? 'Overdue' : `${remainingDays} days`}
              </p>
            </div>
          </div>
          
          {recentUpdates.length > 0 && (
            <>
              <Separator />
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Recent Updates</h3>
                <div className="space-y-2">
                  {recentUpdates.map(update => (
                    <div key={update.id} className="text-sm bg-muted p-2 rounded-md">
                      <div className="flex justify-between">
                        <span className="font-medium">
                          {update.changeAmount > 0 ? '+' : ''}${update.changeAmount.toLocaleString()}
                        </span>
                        <span className="text-muted-foreground">
                          {new Date(update.updatedAt).toLocaleDateString()}
                        </span>
                      </div>
                      {update.note && <p className="text-muted-foreground mt-1">{update.note}</p>}
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </CardContent>
        <CardFooter className="pt-4">
          <Button className="w-full" onClick={() => setIsDialogOpen(true)}>
            <RefreshCcw className="h-4 w-4 mr-2" />
            Update Progress
          </Button>
        </CardFooter>
      </Card>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Goal Progress</DialogTitle>
            <DialogDescription>
              Update your current savings amount for "{goal.name}".
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="current-amount">Current Amount</Label>
              <Input
                id="current-amount"
                type="number"
                placeholder="Enter current amount"
                value={updateAmount}
                onChange={(e) => setUpdateAmount(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="note">Note (optional)</Label>
              <Textarea
                id="note"
                placeholder="Add a note about this update"
                value={updateNote}
                onChange={(e) => setUpdateNote(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateGoal} disabled={updateGoalMutation.isPending}>
              {updateGoalMutation.isPending ? (
                <>
                  <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                  Updating...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Save
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Main goal tracking component
export function GoalTracking() {
  const { user } = useAuth();
  
  // Fetch user's savings goals
  const { data: goals = [], isLoading: isLoadingGoals } = useQuery({
    queryKey: ['/api/savings-goals', { userId: user?.id }],
    queryFn: async ({ queryKey }) => {
      const [_, { userId }] = queryKey as [string, { userId: number }];
      const res = await fetch(`/api/savings-goals?userId=${userId}`);
      if (!res.ok) throw new Error('Failed to fetch goals');
      return res.json();
    },
    enabled: !!user?.id,
  });
  
  // Fetch goal updates
  const { data: updates = [], isLoading: isLoadingUpdates } = useQuery({
    queryKey: ['/api/goal-updates', { userId: user?.id }],
    queryFn: async ({ queryKey }) => {
      const [_, { userId }] = queryKey as [string, { userId: number }];
      const res = await fetch(`/api/goal-updates?userId=${userId}`);
      if (!res.ok) throw new Error('Failed to fetch goal updates');
      return res.json();
    },
    enabled: !!user?.id,
  });
  
  const isLoading = isLoadingGoals || isLoadingUpdates;
  
  // Get updates for a specific goal
  const getUpdatesForGoal = (goalId: number) => {
    return updates.filter((update: GoalUpdate) => update.goalId === goalId);
  };
  
  if (isLoading) {
    return (
      <div className="w-full flex justify-center p-8">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }
  
  if (goals.length === 0) {
    return (
      <Card className="w-full">
        <CardContent className="flex flex-col items-center justify-center p-8">
          <Target className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">No Savings Goals</h3>
          <p className="text-center text-muted-foreground mb-4">
            You haven't set up any savings goals yet. Create a goal to start tracking your progress.
          </p>
          <Button>Create Your First Goal</Button>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="w-full space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Savings Goal Tracking</h2>
        <p className="text-muted-foreground">Track and update your progress towards financial goals</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {goals.map((goal: SavingsGoal) => (
          <GoalCard 
            key={goal.id} 
            goal={goal} 
            updates={getUpdatesForGoal(goal.id)} 
          />
        ))}
      </div>
    </div>
  );
}