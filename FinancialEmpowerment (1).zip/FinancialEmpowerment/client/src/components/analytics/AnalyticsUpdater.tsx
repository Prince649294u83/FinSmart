import { useState } from "react";
import { 
  Card,
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2, LineChart, BarChart3, PieChart, GitBranch, Percent } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface AnalyticsUpdaterProps {
  userId: string;
  onUpdateComplete?: () => void;
}

export function AnalyticsUpdater({ userId, onUpdateComplete }: AnalyticsUpdaterProps) {
  const [activeTab, setActiveTab] = useState("spending");
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: async ({ type, chartType }: { type: string; chartType: string }) => {
      const response = await apiRequest("POST", "/api/analytics/update", {
        userId,
        type,
        chartType
      });
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Analytics Updated",
        description: "Your analytics data has been refreshed.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/reports"] });
      if (onUpdateComplete) {
        onUpdateComplete();
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleUpdate = (chartType: string) => {
    updateMutation.mutate({ type: activeTab, chartType });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Update Analytics</CardTitle>
        <CardDescription>
          Refresh your financial analytics with the latest data
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="spending" onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="spending">Spending</TabsTrigger>
            <TabsTrigger value="income">Income</TabsTrigger>
            <TabsTrigger value="investment">Investments</TabsTrigger>
            <TabsTrigger value="goal">Goals</TabsTrigger>
          </TabsList>
          
          <TabsContent value="spending" className="space-y-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Update your spending analytics to see where your money is going and track monthly expenses.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="flex flex-col items-center justify-center h-24 p-2 space-y-2"
                onClick={() => handleUpdate("pie")}
                disabled={updateMutation.isPending}
              >
                <PieChart className="h-8 w-8" />
                <span className="text-xs">Category Breakdown</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="flex flex-col items-center justify-center h-24 p-2 space-y-2"
                onClick={() => handleUpdate("bar")}
                disabled={updateMutation.isPending}
              >
                <BarChart3 className="h-8 w-8" />
                <span className="text-xs">Monthly Spending</span>
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="income" className="space-y-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Update your income analytics to track your revenue sources and income trends over time.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="flex flex-col items-center justify-center h-24 p-2 space-y-2"
                onClick={() => handleUpdate("doughnut")}
                disabled={updateMutation.isPending}
              >
                <PieChart className="h-8 w-8" />
                <span className="text-xs">Income Sources</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="flex flex-col items-center justify-center h-24 p-2 space-y-2"
                onClick={() => handleUpdate("line")}
                disabled={updateMutation.isPending}
              >
                <LineChart className="h-8 w-8" />
                <span className="text-xs">Income Trends</span>
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="investment" className="space-y-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Update your investment analytics to monitor performance and asset allocation.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="flex flex-col items-center justify-center h-24 p-2 space-y-2"
                onClick={() => handleUpdate("line")}
                disabled={updateMutation.isPending}
              >
                <LineChart className="h-8 w-8" />
                <span className="text-xs">Performance History</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="flex flex-col items-center justify-center h-24 p-2 space-y-2"
                onClick={() => handleUpdate("pie")}
                disabled={updateMutation.isPending}
              >
                <PieChart className="h-8 w-8" />
                <span className="text-xs">Asset Allocation</span>
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="goal" className="space-y-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Update your financial goals analytics to track progress toward your financial objectives.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="flex flex-col items-center justify-center h-24 p-2 space-y-2"
                onClick={() => handleUpdate("progress")}
                disabled={updateMutation.isPending}
              >
                <Percent className="h-8 w-8" />
                <span className="text-xs">Goal Progress</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="flex flex-col items-center justify-center h-24 p-2 space-y-2"
                onClick={() => handleUpdate("tree")}
                disabled={updateMutation.isPending}
              >
                <GitBranch className="h-8 w-8" />
                <span className="text-xs">Goal Hierarchy</span>
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter>
        {updateMutation.isPending && (
          <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Updating analytics...
          </div>
        )}
      </CardFooter>
    </Card>
  );
}