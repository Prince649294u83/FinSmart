import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

const subscriberSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type SubscriberFormValues = z.infer<typeof subscriberSchema>;

const NewsletterSignup = () => {
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  
  const form = useForm<SubscriberFormValues>({
    resolver: zodResolver(subscriberSchema),
    defaultValues: {
      email: "",
    },
  });

  const subscribe = useMutation({
    mutationFn: async (data: SubscriberFormValues) => {
      const response = await apiRequest("POST", "/api/subscribers", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Subscribed!",
        description: "You have been subscribed to our newsletter.",
      });
      setSubmitted(true);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to subscribe. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SubscriberFormValues) => {
    subscribe.mutate(data);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 bg-white">
      <div className="text-center">
        <h2 className="text-base font-semibold text-primary uppercase tracking-wide">Stay Informed</h2>
        <p className="mt-2 text-3xl font-extrabold text-neutral-900 sm:text-4xl">
          Get Financial Tips in Your Inbox
        </p>
        <p className="mt-4 max-w-2xl text-xl text-neutral-500 mx-auto">
          Subscribe to our newsletter for free financial advice, tips and resources.
        </p>
      </div>

      <div className="mt-12 sm:mx-auto sm:max-w-lg">
        {submitted ? (
          <div className="text-center p-6 bg-green-50 rounded-lg border border-green-100">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-green-500 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 className="text-lg font-medium text-green-800">Thanks for subscribing!</h3>
            <p className="mt-2 text-green-600">
              We'll send our best financial tips straight to your inbox.
            </p>
            <Button 
              className="mt-4 bg-green-600 hover:bg-green-700" 
              onClick={() => setSubmitted(false)}
            >
              Subscribe Another Email
            </Button>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="sm:flex">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="min-w-0 flex-1">
                    <FormControl>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        className="block w-full px-4 py-3 rounded-md border-neutral-300 shadow-sm focus:ring-primary focus:border-primary sm:text-sm"
                        {...field}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <div className="mt-3 sm:mt-0 sm:ml-3">
                <Button
                  type="submit"
                  className="block w-full py-3 px-4 rounded-md shadow bg-primary text-white font-medium hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  disabled={subscribe.isPending}
                >
                  {subscribe.isPending ? "Subscribing..." : "Subscribe"}
                </Button>
              </div>
            </form>
          </Form>
        )}
        <p className="mt-3 text-sm text-neutral-500 text-center">
          We care about your data. Read our <a href="#" className="font-medium text-primary hover:text-primary-600">Privacy Policy</a>.
        </p>
      </div>
    </div>
  );
};

export default NewsletterSignup;
