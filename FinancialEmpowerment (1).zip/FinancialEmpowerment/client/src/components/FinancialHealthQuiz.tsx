import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

// Quiz questions
const questions = [
  {
    id: "budgeting",
    question: "Do you follow a monthly budget?",
    options: [
      { value: "1", label: "No, I don't track my spending" },
      { value: "2", label: "I informally keep track in my head" },
      { value: "3", label: "I track major expenses but not everything" },
      { value: "4", label: "Yes, I track all income and expenses regularly" },
    ],
  },
  {
    id: "emergency",
    question: "Do you have an emergency fund?",
    options: [
      { value: "1", label: "No savings at all" },
      { value: "2", label: "Less than 1 month of expenses saved" },
      { value: "3", label: "1-3 months of expenses saved" },
      { value: "4", label: "More than 3 months of expenses saved" },
    ],
  },
  {
    id: "debt",
    question: "How do you manage your debt?",
    options: [
      { value: "1", label: "I have significant debt and struggle with payments" },
      { value: "2", label: "I make minimum payments on my debt" },
      { value: "3", label: "I pay more than the minimum on most debts" },
      { value: "4", label: "I have little to no debt or a solid repayment plan" },
    ],
  },
  {
    id: "retirement",
    question: "Are you saving for retirement?",
    options: [
      { value: "1", label: "No, I haven't started" },
      { value: "2", label: "Very little, inconsistently" },
      { value: "3", label: "Yes, but not as much as I should" },
      { value: "4", label: "Yes, I contribute regularly to retirement accounts" },
    ],
  },
  {
    id: "goals",
    question: "Do you have financial goals?",
    options: [
      { value: "1", label: "No clear financial goals" },
      { value: "2", label: "Vague ideas but nothing specific" },
      { value: "3", label: "Some defined goals without firm timelines" },
      { value: "4", label: "Clear, measurable goals with deadlines" },
    ],
  },
];

// Create schema based on questions
const quizSchema = z.object(
  Object.fromEntries(
    questions.map((q) => [
      q.id,
      z.string().min(1, "Please answer this question"),
    ])
  )
);

type QuizValues = z.infer<typeof quizSchema>;

const FinancialHealthQuiz = () => {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(0);
  const [results, setResults] = useState<{ score: number; recommendations: string[] } | null>(null);
  const [showResults, setShowResults] = useState(false);
  
  const form = useForm<QuizValues>({
    resolver: zodResolver(quizSchema),
    defaultValues: Object.fromEntries(questions.map((q) => [q.id, ""])),
  });

  const submitQuiz = useMutation({
    mutationFn: async (data: QuizValues) => {
      // Calculate score and generate recommendations
      const answers = Object.entries(data).map(([id, value]) => ({
        questionId: id,
        answer: parseInt(value),
      }));
      
      const score = answers.reduce((sum, answer) => sum + answer.answer, 0);
      const maxScore = questions.length * 4;
      const scorePercentage = Math.round((score / maxScore) * 100);
      
      // Generate recommendations based on answers
      const recommendations: string[] = [];
      
      if (parseInt(data.budgeting) < 3) {
        recommendations.push("Create a detailed monthly budget to track your income and expenses");
      }
      
      if (parseInt(data.emergency) < 3) {
        recommendations.push("Start an emergency fund with the goal of saving 3-6 months of expenses");
      }
      
      if (parseInt(data.debt) < 3) {
        recommendations.push("Create a debt repayment plan focusing on high-interest debt first");
      }
      
      if (parseInt(data.retirement) < 3) {
        recommendations.push("Begin contributing to retirement accounts, even small amounts help");
      }
      
      if (parseInt(data.goals) < 3) {
        recommendations.push("Set specific, measurable financial goals with clear timelines");
      }
      
      // In a real app, we would use a real userId
      const payload = {
        userId: 1,
        score: scorePercentage,
        answers,
        recommendations,
      };
      
      const response = await apiRequest("POST", "/api/quiz-results", payload);
      return { score: scorePercentage, recommendations, ...(await response.json()) };
    },
    onSuccess: (data) => {
      setResults({
        score: data.score,
        recommendations: data.recommendations,
      });
      setShowResults(true);
      
      toast({
        title: "Quiz completed",
        description: "Your financial health assessment is ready",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to process your quiz results. Please try again.",
        variant: "destructive",
      });
    },
  });

  const nextStep = async () => {
    const currentQuestion = questions[currentStep].id;
    const isValid = await form.trigger(currentQuestion);
    
    if (isValid) {
      if (currentStep < questions.length - 1) {
        setCurrentStep(currentStep + 1);
      } else {
        // Last question, submit quiz
        form.handleSubmit((data) => {
          submitQuiz.mutate(data);
        })();
      }
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const closeResults = () => {
    setShowResults(false);
    form.reset();
    setCurrentStep(0);
  };

  const getScoreCategory = (score: number) => {
    if (score < 40) return "Needs Attention";
    if (score < 70) return "Moderate";
    if (score < 90) return "Good";
    return "Excellent";
  };

  const getScoreColor = (score: number) => {
    if (score < 40) return "bg-red-500";
    if (score < 70) return "bg-yellow-500";
    if (score < 90) return "bg-blue-500";
    return "bg-green-500";
  };

  return (
    <>
      <Card className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <CardContent className="px-6 py-8">
          <h3 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Financial Health Quiz</h3>
          <p className="text-neutral-600 dark:text-gray-300 mb-6">
            Answer a few questions to get personalized insights on your financial well-being.
          </p>
          
          <div className="mb-6">
            <div className="flex justify-between text-sm text-neutral-500 dark:text-gray-400 mb-2">
              <span>Question {currentStep + 1} of {questions.length}</span>
              <span>{Math.round(((currentStep + 1) / questions.length) * 100)}% complete</span>
            </div>
            <Progress value={((currentStep + 1) / questions.length) * 100} className="h-2" />
          </div>

          <Form {...form}>
            <form>
              <div className="space-y-4">
                {questions.map((q, index) => (
                  <div key={q.id} className={currentStep === index ? "block" : "hidden"}>
                    <FormField
                      control={form.control}
                      name={q.id}
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel className="text-lg font-medium text-neutral-800 dark:text-white">
                            {q.question}
                          </FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              value={field.value}
                              className="space-y-2"
                            >
                              {q.options.map((option) => (
                                <div key={option.value} className="flex items-center space-x-2 p-2 border border-neutral-200 dark:border-gray-700 rounded-md hover:bg-neutral-50 dark:hover:bg-gray-700">
                                  <RadioGroupItem value={option.value} id={`${q.id}-${option.value}`} />
                                  <label htmlFor={`${q.id}-${option.value}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex-grow cursor-pointer text-gray-800 dark:text-gray-200">
                                    {option.label}
                                  </label>
                                </div>
                              ))}
                            </RadioGroup>
                          </FormControl>
                          {form.formState.errors[q.id]?.message && (
                            <p className="text-sm text-red-500 mt-1">
                              {form.formState.errors[q.id]?.message}
                            </p>
                          )}
                        </FormItem>
                      )}
                    />
                  </div>
                ))}
              </div>

              <div className="mt-8 flex justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={prevStep}
                  disabled={currentStep === 0}
                >
                  Previous
                </Button>
                <Button
                  type="button"
                  className="bg-primary hover:bg-primary-600"
                  onClick={nextStep}
                  disabled={submitQuiz.isPending}
                >
                  {currentStep === questions.length - 1
                    ? submitQuiz.isPending
                      ? "Submitting..."
                      : "Submit"
                    : "Next"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      <Dialog open={showResults} onOpenChange={setShowResults}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Your Financial Health Assessment</DialogTitle>
            <DialogDescription>
              Based on your answers, here's how your financial health looks.
            </DialogDescription>
          </DialogHeader>
          
          {results && (
            <div className="py-4">
              <div className="mb-5 text-center">
                <div className="inline-block p-4 rounded-full bg-neutral-100 dark:bg-gray-700 mb-2">
                  <div className="relative w-32 h-32">
                    <svg className="w-32 h-32" viewBox="0 0 36 36">
                      <path
                        className="text-neutral-200 dark:text-gray-600 fill-current"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        strokeWidth="1"
                        stroke="none"
                      />
                      <path
                        className={`${getScoreColor(results.score)} fill-current`}
                        strokeLinecap="round"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        strokeWidth="0"
                        strokeDasharray={`${results.score}, 100`}
                        style={{ 
                          transformOrigin: "center",
                          transform: "rotate(-90deg)"
                        }}
                      />
                      <text x="18" y="20.5" className="text-3xl font-bold" textAnchor="middle" fill="currentColor">
                        {results.score}%
                      </text>
                    </svg>
                  </div>
                </div>
                <h3 className="text-xl font-semibold dark:text-white">{getScoreCategory(results.score)}</h3>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-medium text-lg dark:text-white">Our Recommendations:</h4>
                <ul className="space-y-2">
                  {results.recommendations.map((rec, i) => (
                    <li key={i} className="flex items-start">
                      <span className="inline-flex items-center justify-center flex-shrink-0 w-6 h-6 mr-2 bg-primary rounded-full text-white text-xs">
                        {i + 1}
                      </span>
                      <span className="dark:text-gray-200">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button className="w-full bg-primary" onClick={closeResults}>
              Thanks, I'll Work On These
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default FinancialHealthQuiz;
