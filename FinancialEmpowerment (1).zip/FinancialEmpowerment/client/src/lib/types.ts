export interface ExpenseData {
  housing: number;
  food: number;
  transport: number;
  utilities: number;
  other: number;
}

export interface BudgetSummary {
  totalIncome: number;
  totalExpenses: number;
  remaining: number;
  percentageUsed: number;
}

export interface SavingsGoalSummary {
  name: string;
  percentComplete: number;
  currentAmount: number;
  targetAmount: number;
  monthlySavingsNeeded: number;
  targetDate: Date;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: {
    value: string;
    label: string;
  }[];
}

export interface QuizAnswer {
  questionId: string;
  answer: number;
}

export interface QuizResultData {
  score: number;
  recommendations: string[];
}

export interface LearningResource {
  id: string;
  category: string;
  title: string;
  description: string;
  imageSrc: string;
  imageAlt: string;
  externalUrl: string;
  externalSite: string;
}

export interface Currency {
  code: string;
  name: string;
  symbol: string;
  flag?: string;
}

export interface InvestmentOption {
  id: string;
  name: string;
  description: string;
  minAmount: number;
  maxAmount: number;
  term: string;
  riskLevel: 'Low' | 'Medium' | 'High';
  estimatedReturn: {
    min: number;
    max: number;
  };
  currency: string;
}

export interface InvestmentSummary {
  amount: number;
  currencyCode: string;
  targetCurrency: string;
  exchangeRate: number;
  estimatedReturn: number;
  riskLevel: string;
  maturityDate: Date;
}

export interface CourseData {
  id: number;
  title: string;
  description: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  category: string;
  imageUrl: string;
  thumbnailUrl?: string;
  durationMinutes: number;
  instructor?: string;
  tags?: string[];
  featured?: boolean;
  popularity?: number;
  averageRating?: number;
  enrollmentCount?: number;
  modules?: ModuleData[];
  createdAt?: string;
  updatedAt?: string;
}

export interface ModuleData {
  id: number;
  courseId: number;
  title: string;
  description: string;
  order: number;
  lessons?: LessonData[];
}

export interface LessonData {
  id: number;
  moduleId: number;
  title: string;
  content: string;
  order: number;
  durationMinutes: number;
  videoUrl?: string;
  thumbnailUrl?: string;
  difficulty?: string;
  tags?: string[];
  isVideoLesson?: boolean;
  hasQuiz: boolean;
  quizData?: QuizData;
}

export interface QuizData {
  questions: {
    id: string;
    text: string;
    options: {
      id: string;
      text: string;
      isCorrect: boolean;
    }[];
  }[];
}

export interface UserProgressData {
  id: number;
  userId: number;
  courseId: number;
  moduleId?: number;
  lessonId?: number;
  completed: boolean;
  completedAt?: Date;
  quizScore?: number;
  lastAccessedAt: Date;
}
