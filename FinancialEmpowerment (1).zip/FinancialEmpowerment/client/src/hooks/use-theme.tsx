import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';

type Theme = 'light' | 'dark';

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  // Get the system's color scheme preference
  const getSystemTheme = (): Theme => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return 'light'; // Default to light
  };

  // Initial theme state (from localStorage if it exists, otherwise system preference)
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('theme') as Theme | null;
      return savedTheme || getSystemTheme();
    }
    return 'light';
  });

  // Toggle between light and dark themes
  const toggleTheme = () => {
    setTheme(prev => {
      const newTheme = prev === 'light' ? 'dark' : 'light';
      if (typeof window !== 'undefined') {
        localStorage.setItem('theme', newTheme);
      }
      return newTheme;
    });
  };

  // Effect to apply the theme to the document
  useEffect(() => {
    // Skip if running on server
    if (typeof window === 'undefined') return;

    // Apply the theme class to html element
    const htmlElement = document.documentElement;
    
    if (theme === 'dark') {
      htmlElement.classList.add('dark');
    } else {
      htmlElement.classList.remove('dark');
    }

    // Update the theme.json attributes (specific to Replit)
    try {
      const themeElement = document.getElementById('theme-config') as HTMLElement;
      if (themeElement) {
        const themeData = JSON.parse(themeElement.textContent || '{}');
        themeData.appearance = theme;
        themeElement.textContent = JSON.stringify(themeData);
      }
    } catch (e) {
      console.error('Failed to update theme config:', e);
    }
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}