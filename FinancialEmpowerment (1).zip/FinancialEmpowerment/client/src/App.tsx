import { Route, Switch } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ThemeProvider } from "@/hooks/use-theme";
import { ProtectedRoute } from "@/lib/protected-route";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Home from "@/pages/Home";
import Learn from "@/pages/Learn";
import Tools from "@/pages/Tools";
import Resources from "@/pages/Resources";
import Courses from "@/pages/Courses";
import CoursesList from "@/pages/CoursesList";
import CourseDetail from "@/pages/CourseDetail";
import ProfilePage from "@/pages/ProfilePage";
import Analytics from "@/pages/Analytics";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <ProtectedRoute path="/learn" component={Learn} />
          <ProtectedRoute path="/tools" component={Tools} />
          <ProtectedRoute path="/resources" component={Resources} />
          <Route path="/courses" component={() => {
            // Redirect from /courses to /learn instead
            window.location.href = "/learn#courses";
            return null;
          }} />
          <ProtectedRoute path="/courses/list" component={CoursesList} />
          <Route path="/courses/:id">
            {(params) => (
              <ProtectedRoute 
                path={`/courses/${params.id}`} 
                component={() => <CourseDetail params={params} />} 
              />
            )}
          </Route>
          <ProtectedRoute path="/profile" component={ProfilePage} />
          <ProtectedRoute path="/analytics" component={Analytics} />
          <Route path="/auth" component={AuthPage} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
